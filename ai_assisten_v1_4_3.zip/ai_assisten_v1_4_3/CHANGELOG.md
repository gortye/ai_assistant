## v1.4.3

- Fixed hotkey command parsing test: valid combinations are now returned in canonical form (for example, `Ctrl+Alt+K`) rather than lowercased.
- No changes to hotkey registration or GUI behavior.

# Changelog

## v1.4.2
- Added Enter-to-send behavior to the native command input field.
- Added «гор. клавиши» abbreviation support for show/change hotkey commands.
- Added a two-step, explicitly confirmed self-uninstall flow with a strict portable-install marker.
- Added a temporary cleanup helper that waits for the GUI process to exit before removing the app executable.
- Updated `build_windows.bat` to create the marker file only in the generated `dist` folder.

# Changelog

## v1.4.1
- Fixed the unsafe call when preparing the tray icon during cleanup.
- Removed the UTF-8 BOM from the Windows build batch file to fix its first command.


## v1.4.0

- Added a native Windows assistant window with a command history, input field, and Send button.
- Added system-tray icon with Open and Exit menu items.
- Replaced console-window activation with a global hotkey registered against the GUI window itself.
- Closing/minimizing the main window hides it to the tray; Exit terminates the GUI and its hidden command worker.
- Kept the existing command engine by running it as a hidden child process with redirected stdin/stdout/stderr.
- Added GUI-side hotkey changes so the parent window owns registration and persistence.
- Added a GUI-aware release build script and updated VS Code tasks.

# CHANGELOG

## v1.3.2
- Добавлена обработка коротких вопросов «а громкость?» и «а яркость?» без обязательного вопросительного знака.
- Добавлен диалог смены горячей клавиши: «поменяй горячую клавишу» → ввод сочетания отдельной строкой; есть отмена.
- Добавлена ограниченная коррекция распространённых команд, набранных в английской раскладке (например, `gjvjom` → «помощь»).
- При вводе `cargo test`/`cargo run` внутри приглашения ассистента показывается подсказка о запуске этих команд в терминале.
- Исправлено сообщение о горячих клавишах: поясняется ограничение встроенного терминала VS Code и то, что после выхода обработчик прекращает работу.

# Changelog

## v1.3.1
- Исправлен синтаксис `.cargo/config.toml`: заголовок target и `rustflags` теперь находятся на отдельных строках.
- Обновлён `build_windows.bat`: более понятные ошибки, UTF-8 для консоли, явная проверка EXE и объяснение, почему `dist` не создаётся при ошибке.
- Добавлены задачи VS Code для `cargo run`, `cargo test` и `cargo build --release`.
- Документация уточняет, что проект нужно запускать через Cargo из корня, а не командой `rustc src/main.rs`.

# Changelog

## v1.3

- Добавлен вывод сведений о компьютере: модель, ОС, процессор, GPU, RAM и батарея.
- Добавлены команды просмотра состояния сети и списка сетевых адаптеров.
- Добавлено включение/отключение адаптера по имени с подтверждением отключения и проверкой прав администратора.
- Добавлена настраиваемая глобальная горячая клавиша; по умолчанию Ctrl+Alt+Space восстанавливает окно консоли.
- Настройка горячей клавиши сохраняется в профиле пользователя Windows.
- Добавлены скрипт сборки `build_windows.bat` и инструкция для получения переносимого EXE.
- Улучшена диагностика яркости: работа только с активными дисплеями, проверка фактического значения после команды, обработка частичных отказов, читаемые UTF-8 ошибки.
- Добавлены тесты парсинга команд сети, сведений о ПК, горячих клавиш и запроса «а яркость?».

## v1.2.1

- Добавлена функция `Win32_System_Variant`, необходимая `IMMDevice::Activate` для windows 0.62.2.

## v1.2

- Добавлено управление мастер-громкостью и яркостью Windows.
- После файловых изменений оболочка Windows уведомляется об обновлении.

## v1.1

- Улучшен разбор последовательностей и местоименных ссылок в русских командах.

## Documentation refresh (v1.4.3, no functional changes)

- Expanded source comments and module/function documentation to explain the responsibilities of the main components and important Windows integration points.
- Reworked `README.md` into a GitHub-facing project overview with audience, current capabilities, architecture, examples, build instructions, limitations, safety notes, and future development directions.
- No command behavior or runtime logic was intentionally changed in this documentation pass.
