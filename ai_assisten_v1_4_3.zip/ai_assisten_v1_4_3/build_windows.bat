@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul

echo ==========================================
echo    Local AI Assistant - v1.4.3 Release
echo ==========================================
echo.

rem Проверяем наличие Rust/Cargo до запуска сборки.
where cargo >nul 2>nul
if errorlevel 1 goto :no_cargo

echo Project folder:
echo %CD%
echo.
rem Сначала тестируем парсер и вспомогательную логику.
echo Running tests...
cargo test
if errorlevel 1 goto :build_failed

echo.
rem Release-сборка оптимизированного Windows EXE.
echo Building the GUI application...
cargo build --release
if errorlevel 1 goto :build_failed

if not exist "target\release\local_ai_assistant.exe" goto :missing_exe
rem Создаём портативную папку только после успешных тестов и сборки.
if not exist "dist" mkdir "dist"
copy /y "target\release\local_ai_assistant.exe" "dist\local_ai_assistant.exe" >nul
if errorlevel 1 goto :copy_failed

(
    echo Local AI Assistant v1.4.3
    echo.
    echo Run local_ai_assistant.exe to open the assistant window.
    echo Closing the window hides the assistant in the Windows notification area.
    echo Use the tray icon menu and choose "Exit" to close it completely.
    echo The global hotkey opens the window while the assistant is running.
    echo No VS Code or Rust installation is required on the target PC.
    echo The program uses Windows PowerShell and built-in Windows APIs.
    echo User settings are stored in the current Windows user profile.
) > "dist\README.txt"
rem Маркер позволяет режиму самоудаления отличить нашу dist-папку от произвольного каталога.
> "dist\LOCAL_AI_ASSISTANT_INSTALL.txt" echo LOCAL_AI_ASSISTANT_PORTABLE_INSTALL_V1

echo.
echo Build completed successfully.
echo Executable: %CD%\dist\local_ai_assistant.exe
echo.
echo Opening the dist folder in File Explorer...
start "" "%CD%\dist"
echo Copy the entire dist folder to another Windows PC for testing.
echo Self-uninstall removes only this marked dist folder and the app hotkey setting.
echo.
pause
exit /b 0

:no_cargo
echo ERROR: Cargo was not found. Install Rust from https://rustup.rs/ and reopen the terminal.
goto :failed

:build_failed
echo.
echo ERROR: Tests or compilation failed.
echo The dist folder is not created until the build succeeds.
echo Copy the complete terminal output when asking for help.
goto :failed

:missing_exe
echo ERROR: Cargo reported success, but target\release\local_ai_assistant.exe was not found.
goto :failed

:copy_failed
echo ERROR: Could not copy the executable into dist\.
goto :failed

:failed
echo.
pause
exit /b 1
