//! Команды управления системными настройками Windows.
//!
//! Первая версия поддерживает мастер-громкость и яркость экрана.
//! Логика распознавания команд отделена от вызовов Windows API, поэтому
//! её можно тестировать на любой платформе.

/// Внутренние действия, на которые переводятся русскоязычные фразы.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum SystemCommand {
    /// Прочитать текущую мастер-громкость.
    GetVolume,
    /// Установить мастер-громкость в процентах (0–100).
    SetVolume(u8),
    /// Изменить громкость на заданное число процентных пунктов.
    ChangeVolume(i8),
    /// Включить или выключить mute.
    SetMute(bool),
    /// Прочитать яркость первого доступного активного монитора.
    GetBrightness,
    /// Установить яркость в процентах (0–100).
    SetBrightness(u8),
    /// Изменить яркость на заданное число процентных пунктов.
    ChangeBrightness(i8),
}

/// Фасад: распознаёт системную фразу и передаёт команду платформенному слою.
pub struct SystemControl;

impl SystemControl {
    /// Распознаёт системную команду. `Ok(None)` означает, что фраза не относится
    /// к настройкам Windows; `Err` сообщает об ошибке в самой команде.
    pub fn parse_command(input: &str) -> Result<Option<SystemCommand>, String> {
        let normalized = normalize(input);
        let command_text = remove_quoted_text(&normalized);

        let has_volume = command_text.contains("громкост")
            || command_text.contains("громче")
            || command_text.contains("тише")
            || command_text.contains("звук")
            || command_text.contains("беззвуч")
            || command_text.contains("аудио");
        let has_brightness = command_text.contains("яркост")
            || command_text.contains("ярче")
            || command_text.contains("темнее");

        if has_volume && has_brightness {
            return Err(
                "Пока меняй одну настройку за раз: отдельно громкость или отдельно яркость."
                    .to_string(),
            );
        }

        if has_volume {
            return Self::parse_volume_command(&command_text);
        }

        if has_brightness {
            return Self::parse_brightness_command(&command_text);
        }

        Ok(None)
    }

    /// Выполняет уже распознанное действие; конкретная реализация выбирается по ОС.
    pub fn execute(command: SystemCommand) -> Result<String, String> {
        match command {
            SystemCommand::GetVolume => platform::get_volume(),
            SystemCommand::SetVolume(value) => platform::set_volume(value),
            SystemCommand::ChangeVolume(delta) => platform::change_volume(delta),
            SystemCommand::SetMute(muted) => platform::set_mute(muted),
            SystemCommand::GetBrightness => platform::get_brightness(),
            SystemCommand::SetBrightness(value) => platform::set_brightness(value),
            SystemCommand::ChangeBrightness(delta) => platform::change_brightness(delta),
        }
    }

    /// Распознаёт запросы чтения, установки процента, изменения шага и mute/unmute.
    /// Проверки отключения/включения звука выполняются до числового разбора.
    fn parse_volume_command(text: &str) -> Result<Option<SystemCommand>, String> {
        // Отключение/включение звука проверяется раньше обычного изменения громкости.
        if contains_any(
            text,
            &[
                "выключи звук",
                "выключить звук",
                "выключите звук",
                "отключи звук",
                "отключить звук",
                "выключи аудио",
                "выключить аудио",
                "отключи аудио",
                "заглуши",
                "без звука",
                "беззвучный режим",
            ],
        ) {
            return Ok(Some(SystemCommand::SetMute(true)));
        }

        if contains_any(
            text,
            &[
                "включи звук",
                "включить звук",
                "включите звук",
                "включи аудио",
                "включить аудио",
                "восстанови звук",
                "сними беззвучный режим",
            ],
        ) {
            return Ok(Some(SystemCommand::SetMute(false)));
        }

        if contains_any(
            text,
            &[
                "громче",
                "увеличь громкость",
                "увеличить громкость",
                "прибавь громкость",
                "прибавить громкость",
                "прибавь звук",
                "прибавить звук",
                "увеличь звук",
                "увеличить звук",
                "повысь громкость",
                "сделай звук громче",
                "сделай погромче",
            ],
        ) {
            return Ok(Some(SystemCommand::ChangeVolume(relative_step(text, 1)?)));
        }

        if contains_any(
            text,
            &[
                "тише",
                "уменьши громкость",
                "уменьшить громкость",
                "убавь громкость",
                "убавить громкость",
                "убавь звук",
                "убавить звук",
                "уменьши звук",
                "уменьшить звук",
                "приглуши звук",
                "понизь громкость",
                "сделай звук тише",
                "сделай потише",
            ],
        ) {
            return Ok(Some(SystemCommand::ChangeVolume(relative_step(text, -1)?)));
        }

        if let Some(value) = extract_number(text) {
            return Ok(Some(SystemCommand::SetVolume(validate_percent(value, "громкости")?)));
        }

        if contains_any(
            text,
            &[
                "какая громкость",
                "какая сейчас громкость",
                "какой уровень громкости",
                "сколько громкости",
                "уровень громкости",
                "покажи громкость",
                "узнай громкость",
                "а громкость",
                "и громкость",
            ],
        ) || text.trim() == "громкость"
        {
            return Ok(Some(SystemCommand::GetVolume));
        }

        Ok(None)
    }

    /// Распознаёт запросы яркости экрана и преобразует их в числовую команду.
    fn parse_brightness_command(text: &str) -> Result<Option<SystemCommand>, String> {
        if contains_any(
            text,
            &[
                "ярче",
                "увеличь яркость",
                "увеличить яркость",
                "прибавь яркость",
                "прибавить яркость",
                "увеличь яркости",
                "прибавь яркости",
                "подними яркость",
                "сделай посветлее",
            ],
        ) {
            return Ok(Some(SystemCommand::ChangeBrightness(relative_step(text, 1)?)));
        }

        if contains_any(
            text,
            &[
                "темнее",
                "уменьши яркость",
                "уменьшить яркость",
                "снизь яркость",
                "убавь яркость",
                "убавь яркости",
                "сделай яркость ниже",
                "сделай потемнее",
            ],
        ) {
            return Ok(Some(SystemCommand::ChangeBrightness(relative_step(text, -1)?)));
        }

        if let Some(value) = extract_number(text) {
            return Ok(Some(SystemCommand::SetBrightness(validate_percent(
                value,
                "яркости",
            )?)));
        }

        if contains_any(
            text,
            &[
                "какая яркость",
                "какая сейчас яркость",
                "уровень яркости",
                "покажи яркость",
                "узнай яркость",
                "а яркость",
                "и яркость",
            ],
        ) || text.trim() == "яркость"
        {
            return Ok(Some(SystemCommand::GetBrightness));
        }

        Ok(None)
    }
}

/// Приводит команду к нижнему регистру, заменяет «ё» на «е» и снимает пунктуацию.
fn normalize(input: &str) -> String {
    input
        .trim()
        .to_lowercase()
        .replace('ё', "е")
        .trim_end_matches(|ch: char| matches!(ch, '?' | '!' | '.' | ','))
        .trim()
        .to_string()
}

/// Проверяет команду по набору поддерживаемых словосочетаний.
fn contains_any(text: &str, phrases: &[&str]) -> bool {
    phrases.iter().any(|phrase| text.contains(phrase))
}

/// Извлекает первое целое число из текста (например, `35` из `громкость 35%`).
fn extract_number(text: &str) -> Option<u32> {
    text.split(|ch: char| !ch.is_ascii_digit())
        .filter(|part| !part.is_empty())
        .find_map(|part| part.parse::<u32>().ok())
}

/// Вычисляет относительный шаг изменения. Без числа используется шаг 10 процентов.
fn relative_step(text: &str, direction: i8) -> Result<i8, String> {
    let amount = match extract_number(text) {
        Some(value) => validate_percent(value, "шага изменения")?,
        None => 10,
    };
    Ok(amount as i8 * direction)
}

/// Ограничивает абсолютное значение диапазоном 0–100 и возвращает ошибку при выходе за него.
fn validate_percent(value: u32, setting_name: &str) -> Result<u8, String> {
    if value > 100 {
        return Err(format!(
            "Значение {} должно быть от 0 до 100 процентов, а получено {}.",
            setting_name, value
        ));
    }
    Ok(value as u8)
}

/// Исключает текст в кавычках из поиска командных слов — имя файла не должно
/// случайно выглядеть как команда регулировки звука или экрана.
fn remove_quoted_text(text: &str) -> String {
    let mut result = String::with_capacity(text.len());
    let mut closing_quote: Option<char> = None;

    for ch in text.chars() {
        if let Some(end) = closing_quote {
            result.push(' ');
            if ch == end {
                closing_quote = None;
            }
        } else if let Some(end) = quote_ending(ch) {
            closing_quote = Some(end);
            result.push(' ');
        } else {
            result.push(ch);
        }
    }

    result
}

fn quote_ending(ch: char) -> Option<char> {
    match ch {
        '\'' => Some('\''),
        '"' => Some('"'),
        '«' => Some('»'),
        '„' => Some('“'),
        '“' => Some('”'),
        _ => None,
    }
}

// Windows-реализация: Core Audio COM API управляет мастер-громкостью,
// а PowerShell обращается к WMI-классам активных мониторов.
#[cfg(windows)]
mod platform {
    use std::process::Command;
    use windows::Win32::Media::Audio::Endpoints::IAudioEndpointVolume;
    use windows::Win32::Media::Audio::{
        eMultimedia, eRender, IMMDeviceEnumerator, MMDeviceEnumerator,
    };
    use windows::Win32::System::Com::{
        CoCreateInstance, CoInitializeEx, CoUninitialize, CLSCTX_ALL, COINIT_MULTITHREADED,
    };

    /// Гарантирует вызов `CoUninitialize`, если COM был успешно инициализирован.
    struct ComGuard;

    impl Drop for ComGuard {
        fn drop(&mut self) {
            unsafe { CoUninitialize() };
        }
    }

    /// Создаёт COM-сессию и открывает основной аудиовыход Windows.
    /// Переданная функция выполняется с активным интерфейсом громкости.
    fn with_audio_endpoint<T>(
        operation: impl FnOnce(&IAudioEndpointVolume) -> Result<T, String>,
    ) -> Result<T, String> {
        unsafe {
            CoInitializeEx(None, COINIT_MULTITHREADED)
                .ok()
                .map_err(|error| format!("Не удалось инициализировать Windows COM: {error:?}"))?;
        }
        let _com_guard = ComGuard;

        let enumerator: IMMDeviceEnumerator = unsafe {
            CoCreateInstance(&MMDeviceEnumerator, None, CLSCTX_ALL)
        }
        .map_err(|error| format!("Не удалось получить список аудиоустройств: {error:?}"))?;

        let device = unsafe {
            enumerator.GetDefaultAudioEndpoint(eRender, eMultimedia)
        }
        .map_err(|error| format!("Не найдено стандартное устройство вывода звука: {error:?}"))?;

        let endpoint: IAudioEndpointVolume = unsafe { device.Activate(CLSCTX_ALL, None) }
            .map_err(|error| format!("Не удалось получить управление громкостью: {error:?}"))?;

        operation(&endpoint)
    }

    /// Читает мастер-громкость и флаг выключенного звука.
    pub fn get_volume() -> Result<String, String> {
        with_audio_endpoint(|endpoint| unsafe {
            let volume = endpoint
                .GetMasterVolumeLevelScalar()
                .map_err(|error| format!("Не удалось прочитать громкость: {error:?}"))?;
            let muted = endpoint
                .GetMute()
                .map_err(|error| format!("Не удалось проверить состояние звука: {error:?}"))?
                .as_bool();

            if muted {
                Ok(format!("Текущая громкость: {}%. Звук выключен.", (volume * 100.0).round() as u8))
            } else {
                Ok(format!("Текущая громкость: {}%.", (volume * 100.0).round() as u8))
            }
        })
    }

    /// Устанавливает мастер-громкость и одновременно снимает mute.
    pub fn set_volume(value: u8) -> Result<String, String> {
        with_audio_endpoint(|endpoint| unsafe {
            endpoint
                .SetMasterVolumeLevelScalar(value as f32 / 100.0, std::ptr::null())
                .map_err(|error| format!("Не удалось изменить громкость: {error:?}"))?;
            endpoint
                .SetMute(false, std::ptr::null())
                .map_err(|error| format!("Громкость установлена, но не удалось включить звук: {error:?}"))?;
            Ok(format!("Громкость установлена на {}%.", value))
        })
    }

    /// Меняет текущую громкость на заданное число процентных пунктов.
    pub fn change_volume(delta: i8) -> Result<String, String> {
        with_audio_endpoint(|endpoint| unsafe {
            let current = endpoint
                .GetMasterVolumeLevelScalar()
                .map_err(|error| format!("Не удалось прочитать текущую громкость: {error:?}"))?;
            let next = ((current * 100.0).round() as i16 + delta as i16).clamp(0, 100) as u8;
            endpoint
                .SetMasterVolumeLevelScalar(next as f32 / 100.0, std::ptr::null())
                .map_err(|error| format!("Не удалось изменить громкость: {error:?}"))?;
            endpoint
                .SetMute(false, std::ptr::null())
                .map_err(|error| format!("Громкость изменена, но не удалось включить звук: {error:?}"))?;
            Ok(format!("Громкость изменена: {}%.", next))
        })
    }

    /// Включает или выключает системный mute, не меняя сохранённый уровень громкости.
    pub fn set_mute(muted: bool) -> Result<String, String> {
        with_audio_endpoint(|endpoint| unsafe {
            endpoint
                .SetMute(muted, std::ptr::null())
                .map_err(|error| format!("Не удалось изменить состояние звука: {error:?}"))?;
            if muted {
                Ok("Звук выключен.".to_string())
            } else {
                Ok("Звук включён.".to_string())
            }
        })
    }

    /// Читает текущую яркость первого активного монитора, доступного через WMI.
    pub fn get_brightness() -> Result<String, String> {
        let script = r#"
$ErrorActionPreference = 'Stop'
$utf8 = [System.Text.UTF8Encoding]::new($false)
[Console]::OutputEncoding = $utf8
$OutputEncoding = $utf8
try {
    $monitors = @(Get-CimInstance -Namespace 'root\wmi' -ClassName 'WmiMonitorBrightness' -ErrorAction Stop | Where-Object { $_.Active -eq $true })
    if ($monitors.Count -eq 0) { throw 'Windows не обнаружила активный монитор с программно управляемой яркостью.' }
    [Console]::Out.Write([int]$monitors[0].CurrentBrightness)
} catch {
    [Console]::Out.WriteLine('ERROR:' + $_.Exception.Message)
    exit 1
}
"#;
        let output = run_powershell(script)?;
        let value = output
            .trim()
            .parse::<u8>()
            .map_err(|_| format!("Не удалось прочитать значение яркости: {}", output.trim()))?;
        Ok(format!("Текущая яркость: {}%.", value))
    }

    /// Применяет яркость к активным WMI-мониторам и затем повторно считывает
    /// значения, чтобы проверить, что Windows действительно применила настройку.
    pub fn set_brightness(value: u8) -> Result<String, String> {
        // WMI может вернуть разные статусы для нескольких дисплеев. Считаем
        // команду успешной, если яркость применена хотя бы к одному активному
        // монитору, и отдельно сообщаем о тех, которые отказались.
        let script = format!(
            r#"
$ErrorActionPreference = 'Stop'
$utf8 = [System.Text.UTF8Encoding]::new($false)
[Console]::OutputEncoding = $utf8
$OutputEncoding = $utf8
try {{
    $monitors = @(Get-CimInstance -Namespace 'root\wmi' -ClassName 'WmiMonitorBrightnessMethods' -ErrorAction Stop | Where-Object {{ $_.Active -eq $true }})
    if ($monitors.Count -eq 0) {{ throw 'Windows не обнаружила активный монитор с программным управлением яркостью. На некоторых внешних мониторах эта возможность не поддерживается.' }}

    $successCount = 0
    $failed = @()
    foreach ($monitor in $monitors) {{
        try {{
            $result = Invoke-CimMethod -InputObject $monitor -MethodName 'WmiSetBrightness' -Arguments @{{ Timeout = 1; Brightness = {} }} -ErrorAction Stop
            $returnCode = [int]$result.ReturnValue
            if ($returnCode -eq 0) {{
                $successCount++
            }} else {{
                $failed += ('код ' + $returnCode)
            }}
        }} catch {{
            $failed += $_.Exception.Message
        }}
    }}

    Start-Sleep -Milliseconds 350
    $levels = @(Get-CimInstance -Namespace 'root\wmi' -ClassName 'WmiMonitorBrightness' -ErrorAction SilentlyContinue | Where-Object {{ $_.Active -eq $true }} | ForEach-Object {{ [int]$_.CurrentBrightness }})
    $verifiedCount = @($levels | Where-Object {{ $_ -eq {} }}).Count
    if ($successCount -eq 0 -and $verifiedCount -eq 0) {{
        $details = $failed -join '; '
        throw ('Windows не подтвердила изменение яркости. Ответ WMI: ' + $details)
    }}
    [Console]::Out.WriteLine(('OK|' + $successCount + '|' + $monitors.Count + '|' + ($levels -join ',' ) + '|' + ($failed -join '; ') + '|' + $verifiedCount))
}} catch {{
    [Console]::Out.WriteLine('ERROR:' + $_.Exception.Message)
    exit 1
}}
"#,
            value,
            value
        );

        let output = run_powershell(&script)?;
        let mut parts = output.splitn(6, '|');
        if parts.next() != Some("OK") {
            return Err(format!("Неожиданный ответ Windows при изменении яркости: {output}"));
        }
        let success_count = parts.next().and_then(|value| value.parse::<usize>().ok()).unwrap_or(0);
        let total_count = parts.next().and_then(|value| value.parse::<usize>().ok()).unwrap_or(0);
        let levels = parts.next().unwrap_or("");
        let failed = parts.next().unwrap_or("");
        let verified_count = parts.next().and_then(|value| value.parse::<usize>().ok()).unwrap_or(0);

        let mut message = format!("Яркость установлена на {}%. WMI подтвердил {} из {} активных мониторов; фактическое значение совпало на {} мониторах.", value, success_count, total_count, verified_count);
        if !levels.is_empty() {
            let formatted_levels = levels
                .split(',')
                .map(|level| format!("{}%", level.trim()))
                .collect::<Vec<_>>()
                .join(", ");
            message.push_str(&format!(" Текущие значения по данным Windows: {formatted_levels}."));
        }
        if !failed.is_empty() && verified_count == 0 {
            message.push_str(&format!(" Ответ мониторов: {failed}"));
        } else if !failed.is_empty() {
            message.push_str(" Некоторые мониторы вернули предупреждение, но фактическая яркость подтверждена чтением.");
        }
        Ok(message)
    }

    /// Считывает текущий уровень и изменяет его на указанный шаг, не выходя за 0–100%.
    pub fn change_brightness(delta: i8) -> Result<String, String> {
        let current = get_brightness_value()?;
        let next = (current as i16 + delta as i16).clamp(0, 100) as u8;
        set_brightness(next)
    }

    /// Возвращает числовое значение яркости для вычисления относительного шага.
    fn get_brightness_value() -> Result<u8, String> {
        let script = r#"
$ErrorActionPreference = 'Stop'
$utf8 = [System.Text.UTF8Encoding]::new($false)
[Console]::OutputEncoding = $utf8
$OutputEncoding = $utf8
try {
    $monitors = @(Get-CimInstance -Namespace 'root\wmi' -ClassName 'WmiMonitorBrightness' -ErrorAction Stop | Where-Object { $_.Active -eq $true })
    if ($monitors.Count -eq 0) { throw 'Windows не обнаружила активный монитор с программно управляемой яркостью.' }
    [Console]::Out.Write([int]$monitors[0].CurrentBrightness)
} catch {
    [Console]::Out.WriteLine('ERROR:' + $_.Exception.Message)
    exit 1
}
"#;
        run_powershell(script)?
            .trim()
            .parse::<u8>()
            .map_err(|_| "Не удалось определить текущую яркость.".to_string())
    }

    /// Запускает PowerShell без профиля и разбирает единый текстовый ответ/ошибку.
    fn run_powershell(script: &str) -> Result<String, String> {
        let output = Command::new("powershell.exe")
            .args(["-NoProfile", "-NonInteractive", "-Command", script])
            .output()
            .map_err(|error| format!("Не удалось запустить PowerShell: {error}"))?;

        let stdout = String::from_utf8_lossy(&output.stdout).trim().to_string();
        if output.status.success() {
            if let Some(message) = stdout.strip_prefix("ERROR:") {
                return Err(message.trim().to_string());
            }
            Ok(stdout)
        } else {
            let details = stdout
                .strip_prefix("ERROR:")
                .map(str::trim)
                .filter(|message| !message.is_empty())
                .map(str::to_string)
                .unwrap_or_else(|| format!("PowerShell завершился с кодом {:?}.", output.status.code()));
            Err(details)
        }
    }
}

// Заглушки для сборки на других ОС: распознавание команд возможно,
// но фактическое управление настройками пока реализовано только для Windows.
#[cfg(not(windows))]
mod platform {
    fn unsupported<T>() -> Result<T, String> {
        Err("Управление настройками пока реализовано только для Windows.".to_string())
    }

    pub fn get_volume() -> Result<String, String> { unsupported() }
    pub fn set_volume(_: u8) -> Result<String, String> { unsupported() }
    pub fn change_volume(_: i8) -> Result<String, String> { unsupported() }
    pub fn set_mute(_: bool) -> Result<String, String> { unsupported() }
    pub fn get_brightness() -> Result<String, String> { unsupported() }
    pub fn set_brightness(_: u8) -> Result<String, String> { unsupported() }
    pub fn change_brightness(_: i8) -> Result<String, String> { unsupported() }

}

#[cfg(test)]
mod tests {
    use super::{SystemCommand, SystemControl};

    #[test]
    fn parses_volume_percentage() {
        assert_eq!(
            SystemControl::parse_command("Установи громкость на 45%"),
            Ok(Some(SystemCommand::SetVolume(45)))
        );
    }

    #[test]
    fn parses_volume_relative_commands() {
        assert_eq!(
            SystemControl::parse_command("Сделай звук громче"),
            Ok(Some(SystemCommand::ChangeVolume(10)))
        );
        assert_eq!(
            SystemControl::parse_command("Убавь громкость"),
            Ok(Some(SystemCommand::ChangeVolume(-10)))
        );
    }

    #[test]
    fn parses_custom_relative_step() {
        assert_eq!(
            SystemControl::parse_command("Сделай звук громче на 15%"),
            Ok(Some(SystemCommand::ChangeVolume(15)))
        );
        assert_eq!(
            SystemControl::parse_command("Уменьши яркость на 20"),
            Ok(Some(SystemCommand::ChangeBrightness(-20)))
        );
    }

    #[test]
    fn parses_mute_and_unmute() {
        assert_eq!(
            SystemControl::parse_command("Выключи звук"),
            Ok(Some(SystemCommand::SetMute(true)))
        );
        assert_eq!(
            SystemControl::parse_command("Включи звук"),
            Ok(Some(SystemCommand::SetMute(false)))
        );
    }

    #[test]
    fn parses_brightness_commands() {
        assert_eq!(
            SystemControl::parse_command("Поставь яркость 70 процентов"),
            Ok(Some(SystemCommand::SetBrightness(70)))
        );
        assert_eq!(
            SystemControl::parse_command("Сделай экран темнее"),
            Ok(Some(SystemCommand::ChangeBrightness(-10)))
        );
    }

    #[test]
    fn parses_current_setting_questions() {
        assert_eq!(
            SystemControl::parse_command("Какая сейчас громкость?"),
            Ok(Some(SystemCommand::GetVolume))
        );
        assert_eq!(
            SystemControl::parse_command("Какая сейчас яркость?"),
            Ok(Some(SystemCommand::GetBrightness))
        );
        assert_eq!(
            SystemControl::parse_command("А яркость?"),
            Ok(Some(SystemCommand::GetBrightness))
        );
        assert_eq!(
            SystemControl::parse_command("а яркость"),
            Ok(Some(SystemCommand::GetBrightness))
        );
        assert_eq!(
            SystemControl::parse_command("А громкость?"),
            Ok(Some(SystemCommand::GetVolume))
        );
        assert_eq!(
            SystemControl::parse_command("а громкость"),
            Ok(Some(SystemCommand::GetVolume))
        );
    }

    #[test]
    fn accepts_common_russian_variants() {
        assert_eq!(
            SystemControl::parse_command("Увеличь звук"),
            Ok(Some(SystemCommand::ChangeVolume(10)))
        );
        assert_eq!(
            SystemControl::parse_command("Прибавь яркости"),
            Ok(Some(SystemCommand::ChangeBrightness(10)))
        );
    }

    #[test]
    fn rejects_out_of_range_percentages() {
        assert!(SystemControl::parse_command("Громкость 120%").is_err());
        assert!(SystemControl::parse_command("Яркость 101").is_err());
    }

    #[test]
    fn ignores_system_words_inside_quotes() {
        assert_eq!(
            SystemControl::parse_command("Создай файл 'громкость 20'"),
            Ok(None)
        );
    }

    #[test]
    fn does_not_mix_volume_and_brightness_in_one_phrase() {
        assert!(SystemControl::parse_command("Громкость 50 и яркость 70").is_err());
    }
}
