/// Разбор русскоязычных команд файлового ассистента.
///
/// Поддерживаются:
/// - последовательные маркеры: «а потом», «затем», «после этого», «потом»;
/// - соединение независимых операций через «и»;
/// - сокращённые конструкции: «создай папку A и файл B»;
/// - местоименные ссылки на последнюю созданную папку: «в неё», «в ней»;
/// - названия в одинарных, двойных и русских кавычках.
pub struct CommandParser;

impl CommandParser {
    /// Показывает короткую встроенную справку по примерам файловых и системных команд.
    pub fn print_help() {
        println!("\n=== СПРАВОЧНИК И ПРАВИЛА ОБЩЕНИЯ ===");
        println!("  • Создай папку 'Проекты'");
        println!("  • В папке 'Проекты' сделай файл 'Заметки'");
        println!("  • Создай папку 'Важное', а потом сделай файл 'Счёт' на рабочем столе");
        println!("  • Создай папку 'Учёба' и в неё сделай файл 'Математика'");
        println!("  • Удали файлы 'Черновик', 'Копия'");
        println!("\n=== УПРАВЛЕНИЕ WINDOWS ===");
        println!("  • Установи громкость на 35%");
        println!("  • Сделай звук громче / тише");
        println!("  • Выключи звук / включи звук");
        println!("  • Установи яркость 70%");
        println!("  • Сделай экран ярче / темнее");
        println!("  • Какая сейчас громкость? / Какая яркость?\n");
    }

    /// Возвращает список действий в порядке их выполнения.
    ///
    /// `last_folder` — последняя папка, созданная ранее или в текущей фразе.
    /// Для местоимений «в неё/в ней» используется именно этот контекст.
    pub fn parse_intent(
        input: &str,
        last_folder: &Option<String>,
    ) -> Vec<(String, Vec<String>)> {
        let mut results = Vec::new();
        let sub_commands = Self::split_into_sub_commands(input);
        let mut current_context = last_folder.clone();
        let mut inherited_action: Option<&'static str> = None;

        for sub_input in sub_commands {
            let cleaned = Self::clean_clause(&sub_input);
            if cleaned.is_empty() {
                continue;
            }

            let lower = cleaned.to_lowercase();
            let unquoted_lower = Self::remove_quoted_text(&lower);
            let effective_input = if Self::has_action_verb(&unquoted_lower) {
                inherited_action = Self::action_verb(&unquoted_lower);
                cleaned
            } else if let Some(action) = inherited_action {
                if Self::looks_like_continuation(&lower) {
                    format!("{} {}", action, cleaned)
                } else {
                    cleaned
                }
            } else {
                cleaned
            };

            let Some((action, args)) =
                Self::parse_single_intent(&effective_input, &current_context)
            else {
                // Не выполняем только понятную часть составной фразы:
                // неизвестная часть может менять смысл места или порядка действий.
                return Vec::new();
            };

            // Сохраняем последнюю созданную папку, чтобы следующая часть
            // команды могла сослаться на неё словами «в неё» или «в ней».
            match action.as_str() {
                "создать_папки" => {
                    if let Some(last_created) = args.last() {
                        current_context = Some(last_created.clone());
                    }
                }
                "создать_файлы" => {
                    if let Some(file_path) = args.first() {
                        if let Some(parent) = Self::parent_path_from_target(file_path) {
                            current_context = Some(parent);
                        }
                    }
                }
                "очистить_папку" => {
                    if let Some(folder) = args.first() {
                        current_context = Some(folder.clone());
                    }
                }
                "переименовать" => {
                    if args.len() >= 2 && current_context.as_deref() == Some(args[0].as_str()) {
                        current_context = Some(args[1].clone());
                    }
                }
                _ => {}
            }
            results.push((action, args));
        }

        results
    }

    /// Разделяет фразу на отдельные операции, не трогая текст внутри кавычек.
    /// Явные маркеры последовательности имеют приоритет над союзом «и».
    fn split_into_sub_commands(input: &str) -> Vec<String> {
        let input = Self::strip_leading_word(input, "сначала");
        let chars: Vec<char> = input.chars().collect();
        let mut parts = Vec::new();
        let mut quote_end: Option<char> = None;
        let mut part_start = 0usize;
        let mut i = 0usize;

        while i < chars.len() {
            let ch = chars[i];

            if let Some(end) = quote_end {
                if ch == end {
                    quote_end = None;
                }
                i += 1;
                continue;
            }

            if let Some(end) = Self::quote_ending(ch) {
                quote_end = Some(end);
                i += 1;
                continue;
            }

            let at_left_boundary = i == 0
                || chars[i - 1].is_whitespace()
                || matches!(chars[i - 1], ',' | ';');

            if at_left_boundary {
                let sequence_markers = [
                    "а потом",
                    "а затем",
                    "после этого",
                    "затем",
                    "потом",
                ];

                let mut matched = None;
                for marker in sequence_markers {
                    if Self::marker_matches(&chars, i, marker)
                        && Self::right_boundary(&chars, i + marker.chars().count())
                    {
                        matched = Some(marker.chars().count());
                        break;
                    }
                }

                if let Some(marker_len) = matched {
                    let end_byte = Self::byte_offset(input, i);
                    let previous = input[part_start..end_byte]
                        .trim()
                        .trim_end_matches(|c| c == ',' || c == ';')
                        .trim();
                    if !previous.is_empty() {
                        parts.push(previous.to_string());
                    }

                    i += marker_len;
                    while i < chars.len()
                        && (chars[i].is_whitespace() || matches!(chars[i], ',' | ';'))
                    {
                        i += 1;
                    }
                    part_start = Self::byte_offset(input, i);
                    continue;
                }

                // «И» разделяет операции только тогда, когда после него
                // начинается новая команда/объект или указание места.
                if Self::marker_matches(&chars, i, "и")
                    && Self::right_boundary(&chars, i + 1)
                {
                    let next = Self::skip_spaces(&chars, i + 1);
                    if Self::should_split_after_and(&chars, next) {
                        let end_byte = Self::byte_offset(input, i);
                        let previous = input[part_start..end_byte]
                            .trim()
                            .trim_end_matches(|c| c == ',' || c == ';')
                            .trim();
                        if !previous.is_empty() {
                            parts.push(previous.to_string());
                        }

                        i = next;
                        part_start = Self::byte_offset(input, i);
                        continue;
                    }
                }
            }

            i += 1;
        }

        let tail = input[part_start..]
            .trim()
            .trim_end_matches(|c| c == ',' || c == ';')
            .trim();
        if !tail.is_empty() {
            parts.push(tail.to_string());
        }

        if parts.is_empty() {
            vec![input.trim().to_string()]
        } else {
            parts
        }
    }

    /// Решает, является ли «и» границей двух действий, а не частью перечисления.
    /// Например, «создай папки A и B» остаётся одной операцией, а
    /// «создай папку A и файл B» разбивается на две.
    fn should_split_after_and(chars: &[char], next: usize) -> bool {
        if next >= chars.len() {
            return false;
        }

        let rest: String = chars[next..].iter().collect();
        let rest = rest.trim_start().to_lowercase();

        // Союз внутри перечисления названий («папки A и B») не разделяем:
        // следующее слово должно обозначать новую операцию или её объект.
        let action_starts = [
            "создай", "создать", "создайте", "сделай", "сделать", "сделайте",
            "добавь", "добавить", "удали", "удалить", "удалите", "сотри",
            "стереть", "убери", "убрать", "переименуй", "переименовать",
        ];
        if action_starts.iter().any(|word| Self::starts_with_word(&rest, word)) {
            return true;
        }

        let object_starts = [
            "папка", "папку", "папки", "каталог", "каталоги", "каталогов",
            "директория", "директорию", "директории", "файл", "файлы", "файлов",
            "документ", "документы", "документов", "таблица", "таблицу",
            "таблицы", "презентация", "презентацию", "презентации",
        ];
        if object_starts.iter().any(|word| Self::starts_with_word(&rest, word)) {
            return true;
        }

        let location_starts = [
            "в неё", "в нее", "в ней", "в эту", "в этой",
            "в папке", "в папку", "в каталоге", "в каталог", "в директории",
            "в директорию", "внутри", "на рабочем столе", "на рабочий стол",
        ];

        let unquoted_rest = Self::remove_quoted_text(&rest);
        location_starts.iter().any(|location| {
            rest.starts_with(location)
                && (action_starts
                    .iter()
                    .any(|word| unquoted_rest.contains(word))
                    || object_starts
                        .iter()
                        .any(|word| unquoted_rest.contains(word)))
        })
    }

    /// Преобразует одну уже выделенную часть фразы в пару `(действие, аргументы)`.
    /// Здесь распознаются тип объекта, глагол, имена в кавычках и место назначения.
    fn parse_single_intent(
        input: &str,
        last_folder: &Option<String>,
    ) -> Option<(String, Vec<String>)> {
        let input_lower = input.to_lowercase();
        let unquoted_lower = Self::remove_quoted_text(&input_lower);
        let quoted = Self::extract_quoted_strings(input);

        // Два разных адреса назначения в одном блоке — неоднозначная команда.
        if Self::has_conflicting_targets(&input_lower, input, last_folder) {
            return None;
        }

        // 1. Удаление и очистка папок.
        let is_delete = Self::contains_any(
            &unquoted_lower,
            &["удали", "удалить", "удалите", "сотри", "стереть", "убери", "убрать"],
        );

        if is_delete {
            let is_all = Self::contains_any(
                &unquoted_lower,
                &["все", "всё", "весь", "содержимое", "полностью"],
            );
            let names_folder = Self::contains_any(
                &unquoted_lower,
                &[
                    "в папке", "в папку", "в каталоге", "в каталог",
                    "содержимое папки", "содержимое каталога",
                ],
            ) || Self::has_folder_pronoun(&input_lower);

            if is_all && names_folder {
                let target_dir = Self::extract_parent_folder_anywhere(
                    &input_lower,
                    input,
                    last_folder,
                );
                if let Some(target_dir) = target_dir {
                    return Some(("очистить_папку".to_string(), vec![target_dir]));
                }
                return None;
            }

            if !quoted.is_empty() {
                return Some(("удалить_много".to_string(), quoted));
            }
        }

        // 2. Переименование.
        if Self::contains_any(&unquoted_lower, &["переименуй", "переименовать", "переименуйте"])
            && quoted.len() >= 2
        {
            return Some((
                "переименовать".to_string(),
                vec![quoted[0].clone(), quoted[1].clone()],
            ));
        }

        // 3. Создание файлов и папок.
        let is_create = Self::contains_any(
            &unquoted_lower,
            &[
                "создай", "создать", "создайте", "сделай", "сделать", "сделайте",
                "добавь", "добавить", "напиши",
            ],
        );

        if is_create {
            let is_file = Self::contains_any(
                &unquoted_lower,
                &[
                    "файл", "файлы", "документ", "документы", "таблицу", "таблица",
                    "таблицы", "презентацию", "презентация", "презентации", "текст", "напиши",
                ],
            );

            let target_folder =
                Self::extract_parent_folder_anywhere(&input_lower, input, last_folder);
            if Self::has_folder_location_phrase(&input_lower) && target_folder.is_none() {
                return None;
            }

            let mut creation_items = quoted;
            if let Some(ref parent) = target_folder {
                creation_items.retain(|item| item != parent);
            }

            if creation_items.is_empty() {
                return None;
            }

            if is_file {
                let mut file_names = creation_items;
                let mut content = String::new();

                if Self::contains_any(&unquoted_lower, &["напиши", "текст"])
                    && file_names.len() > 1
                {
                    content = file_names.pop().unwrap_or_default();
                }

                let mut result_args = Vec::new();
                for name in file_names {
                    let full_path = if let Some(ref parent) = target_folder {
                        format!("{}/{}", parent, name)
                    } else {
                        name
                    };
                    result_args.push(full_path);
                }
                // Последний аргумент — содержимое файла (пустая строка, если его нет).
                result_args.push(content);
                return Some(("создать_файлы".to_string(), result_args));
            }

            let mut result_args = Vec::new();
            for name in creation_items {
                let full_path = if let Some(ref parent) = target_folder {
                    format!("{}/{}", parent, name)
                } else {
                    name
                };
                result_args.push(full_path);
            }

            return Some(("создать_папки".to_string(), result_args));
        }

        None
    }

    /// Находит папку, указанную явно («в папке X», «в папку X»), либо
    /// разрешает местоимение («в неё», «в ней») через текущий контекст.
    /// Явный адрес задаёт новое место, местоимение ссылается на последнюю папку.
    fn extract_parent_folder_anywhere(
        input_lower: &str,
        raw_input: &str,
        last_folder: &Option<String>,
    ) -> Option<String> {
        let explicit_locations = [
            "в этой папке",
            "в эту папку",
            "в этом каталоге",
            "в тот каталог",
            "в этой директории",
            "в эту директорию",
            "в папке",
            "в папку",
            "в каталоге",
            "в каталог",
            "в директории",
            "в директорию",
            "внутри папки",
            "внутри каталога",
            "внутри директории",
            "содержимое папки",
            "содержимое каталога",
        ];

        for keyword in explicit_locations {
            if let Some(pos) = Self::find_unquoted_phrase(input_lower, keyword) {
                let after_keyword = pos + keyword.len();
                if after_keyword <= raw_input.len() {
                    let names_after = Self::extract_quoted_strings(&raw_input[after_keyword..]);
                    if let Some(folder_name) = names_after.first() {
                        return Some(folder_name.clone());
                    }
                }
            }
        }

        let pronouns = [
            "в неё", "в нее", "в ней", "в эту", "в этой",
            "внутри неё", "внутри нее", "внутри ней",
        ];

        if pronouns
            .iter()
            .any(|phrase| Self::find_unquoted_phrase(input_lower, phrase).is_some())
            || Self::find_unquoted_phrase(input_lower, "внутри").is_some()
        {
            return last_folder.clone();
        }

        // «На рабочем столе» — явное указание на стандартное место хранения.
        // FileManager и так размещает относительные пути на рабочем столе,
        // поэтому дополнительный префикс здесь не нужен.
        None
    }


    /// Возвращает родительский путь для файла, чтобы обновить контекст папки.
    fn parent_path_from_target(path: &str) -> Option<String> {
        let parent = path
            .rsplit_once('/')
            .map(|(parent, _)| parent)
            .or_else(|| path.rsplit_once('\\').map(|(parent, _)| parent))?;

        if parent.is_empty() {
            None
        } else {
            Some(parent.to_string())
        }
    }

    /// Проверяет наличие местоименной ссылки на папку вне кавычек.
    fn has_folder_pronoun(input_lower: &str) -> bool {
        ["в неё", "в нее", "в ней", "в эту", "в этой", "внутри неё", "внутри нее"]
            .iter()
            .any(|phrase| Self::find_unquoted_phrase(input_lower, phrase).is_some())
    }

    /// Проверяет, содержит ли команда конструкцию, обозначающую расположение внутри папки.
    fn has_folder_location_phrase(input_lower: &str) -> bool {
        let locations = [
            "в этой папке", "в эту папку", "в этом каталоге", "в тот каталог",
            "в этой директории", "в эту директорию", "в папке", "в папку",
            "в каталоге", "в каталог", "в директории", "в директорию",
            "внутри папки", "внутри каталога", "внутри директории",
        ];
        locations
            .iter()
            .any(|phrase| Self::find_unquoted_phrase(input_lower, phrase).is_some())
            || Self::has_folder_pronoun(input_lower)
            || Self::find_unquoted_phrase(input_lower, "внутри").is_some()
    }

    /// Выявляет противоречащие друг другу места назначения в одной команде.
    /// При неоднозначности парсер отказывается выполнять команду.
    fn has_conflicting_targets(
        input_lower: &str,
        raw_input: &str,
        last_folder: &Option<String>,
    ) -> bool {
        let explicit_locations = [
            "в этой папке", "в эту папку", "в этом каталоге", "в тот каталог",
            "в этой директории", "в эту директорию", "в папке", "в папку",
            "в каталоге", "в каталог", "в директории", "в директорию",
            "внутри папки", "внутри каталога", "внутри директории",
            "содержимое папки", "содержимое каталога",
        ];
        let mut targets: Vec<String> = Vec::new();

        for keyword in explicit_locations {
            for pos in Self::find_all_unquoted_phrases(input_lower, keyword) {
                let after_keyword = pos + keyword.len();
                if after_keyword <= raw_input.len() {
                    if let Some(folder) = Self::extract_quoted_strings(&raw_input[after_keyword..]).first() {
                        targets.push(folder.clone());
                    }
                }
            }
        }

        let pronouns = ["в неё", "в нее", "в ней", "в эту", "в этой", "внутри неё", "внутри нее"];
        let has_pronoun = pronouns
            .iter()
            .any(|phrase| Self::find_unquoted_phrase(input_lower, phrase).is_some());
        if has_pronoun {
            if let Some(folder) = last_folder {
                targets.push(folder.clone());
            }
        }

        let first = match targets.first() {
            Some(value) => value,
            None => return false,
        };
        targets.iter().any(|target| target != first)
    }

    /// Ищет все вхождения фразы вне кавычек и возвращает байтовые позиции.
    fn find_all_unquoted_phrases(text: &str, phrase: &str) -> Vec<usize> {
        let chars: Vec<char> = text.chars().collect();
        let mut positions = Vec::new();
        let mut quote_end: Option<char> = None;
        let mut i = 0usize;

        while i < chars.len() {
            let ch = chars[i];
            if let Some(end) = quote_end {
                if ch == end {
                    quote_end = None;
                }
                i += 1;
                continue;
            }
            if let Some(end) = Self::quote_ending(ch) {
                quote_end = Some(end);
                i += 1;
                continue;
            }

            if Self::marker_matches(&chars, i, phrase) {
                let end = i + phrase.chars().count();
                if (i == 0 || !chars[i - 1].is_alphanumeric())
                    && (end >= chars.len() || !chars[end].is_alphanumeric())
                {
                    positions.push(Self::byte_offset(text, i));
                    i = end;
                    continue;
                }
            }
            i += 1;
        }

        positions
    }

    /// Собирает имена объектов из одинарных, двойных и русских кавычек.
    fn extract_quoted_strings(text: &str) -> Vec<String> {
        let mut results = Vec::new();
        let mut closing_quote: Option<char> = None;
        let mut current = String::new();

        for ch in text.chars() {
            if let Some(end) = closing_quote {
                if ch == end {
                    results.push(current.trim().to_string());
                    current.clear();
                    closing_quote = None;
                } else {
                    current.push(ch);
                }
            } else if let Some(end) = Self::quote_ending(ch) {
                closing_quote = Some(end);
                current.clear();
            }
        }

        results
    }

    /// Возвращает соответствующий закрывающий символ для поддерживаемой кавычки.
    fn quote_ending(ch: char) -> Option<char> {
        match ch {
            '\'' => Some('\''),
            '"' => Some('"'),
            '«' => Some('»'),
            '„' => Some('“'),
            '“' => Some('”'),
            _ => None,
        }
    }

    /// Заменяет содержимое кавычек пробелами, чтобы слова в имени файла
    /// не принимались за команды или разделители.
    fn remove_quoted_text(text: &str) -> String {
        let mut result = String::with_capacity(text.len());
        let mut closing_quote: Option<char> = None;

        for ch in text.chars() {
            if let Some(end) = closing_quote {
                result.push(' ');
                if ch == end {
                    closing_quote = None;
                }
            } else if let Some(end) = Self::quote_ending(ch) {
                closing_quote = Some(end);
                result.push(' ');
            } else {
                result.push(ch);
            }
        }

        result
    }

    /// Ищет первое вхождение фразы за пределами кавычек.
    fn find_unquoted_phrase(text: &str, phrase: &str) -> Option<usize> {
        let chars: Vec<char> = text.chars().collect();
        let mut quote_end: Option<char> = None;
        let mut i = 0usize;

        while i < chars.len() {
            let ch = chars[i];
            if let Some(end) = quote_end {
                if ch == end {
                    quote_end = None;
                }
                i += 1;
                continue;
            }

            if let Some(end) = Self::quote_ending(ch) {
                quote_end = Some(end);
                i += 1;
                continue;
            }

            if Self::marker_matches(&chars, i, phrase) {
                let end = i + phrase.chars().count();
                if (i == 0 || !chars[i - 1].is_alphanumeric())
                    && (end >= chars.len() || !chars[end].is_alphanumeric())
                {
                    return Some(Self::byte_offset(text, i));
                }
            }

            i += 1;
        }

        None
    }

    /// Убирает начальное служебное слово, если оно отделено пробелом/запятой.
    fn strip_leading_word<'a>(input: &'a str, word: &str) -> &'a str {
        let trimmed = input.trim_start();
        let lower = trimmed.to_lowercase();
        if lower.starts_with(word)
            && lower
                .chars()
                .nth(word.chars().count())
                .map(|c| c.is_whitespace() || c == ',')
                .unwrap_or(true)
        {
            let byte_len = word.len();
            trimmed[byte_len..].trim_start_matches(|c: char| c.is_whitespace() || c == ',')
        } else {
            trimmed
        }
    }

    /// Удаляет внешние пробелы и разделительную пунктуацию у одной части команды.
    fn clean_clause(input: &str) -> String {
        input
            .trim()
            .trim_matches(|c: char| c == ',' || c == ';' || c == '.')
            .trim()
            .to_string()
    }

    /// Сопоставляет варианты русских глаголов с внутренним каноническим действием.
    fn action_verb(input_lower: &str) -> Option<&'static str> {
        if Self::contains_any(input_lower, &["создай", "создать", "создайте"]) {
            Some("создай")
        } else if Self::contains_any(input_lower, &["сделай", "сделать", "сделайте"]) {
            Some("сделай")
        } else if Self::contains_any(input_lower, &["добавь", "добавить"]) {
            Some("добавь")
        } else if Self::contains_any(input_lower, &["напиши", "написать"]) {
            Some("напиши")
        } else if Self::contains_any(input_lower, &["удали", "удалить", "удалите"]) {
            Some("удали")
        } else if Self::contains_any(input_lower, &["сотри", "стереть"]) {
            Some("сотри")
        } else if Self::contains_any(input_lower, &["убери", "убрать"]) {
            Some("убери")
        } else if Self::contains_any(input_lower, &["переименуй", "переименовать", "переименуйте"]) {
            Some("переименуй")
        } else {
            None
        }
    }

    /// Проверяет, содержит ли часть команды один из поддерживаемых глаголов.
    fn has_action_verb(input_lower: &str) -> bool {
        Self::action_verb(input_lower).is_some()
    }

    /// Определяет, можно ли восстановить пропущенный глагол из предыдущей части.
    fn looks_like_continuation(input_lower: &str) -> bool {
        let text = input_lower.trim_start();
        let unquoted = Self::remove_quoted_text(text);

        // Если часть начинается непосредственно с типа объекта, можно
        // унаследовать глагол: «... и файл 'B'».
        let object_starts = [
            "папка", "папку", "папки", "каталог", "каталоги", "директория",
            "директорию", "директории", "файл", "файлы", "документ", "документы",
            "таблицу", "таблица", "таблицы", "презентацию", "презентация",
        ];
        if object_starts.iter().any(|word| Self::starts_with_word(text, word)) {
            return true;
        }

        // Если часть начинается с места, после него должно быть ещё одно
        // действие или объект. Одного «в папку 'X'» недостаточно: это не
        // самостоятельная команда создания папки.
        let location_starts = [
            "в этой папке", "в эту папку", "в этом каталоге", "в тот каталог",
            "в этой директории", "в эту директорию", "внутри папки",
            "внутри каталога", "внутри директории", "в папке", "в папку",
            "в каталоге", "в каталог", "в директории", "в директорию",
            "внутри", "в неё", "в нее", "в ней", "в эту", "в этой",
            "на рабочем столе", "на рабочий стол",
        ];

        for location in location_starts {
            if text.starts_with(location) {
                let remainder = unquoted[location.len()..].trim_start();
                let has_action = Self::action_verb(remainder).is_some();
                let has_object = object_starts
                    .iter()
                    .any(|word| remainder.contains(word));
                return has_action || has_object;
            }
        }

        false
    }

    /// Проверяет, встречается ли хотя бы одна подстрока из списка.
    fn contains_any(text: &str, words: &[&str]) -> bool {
        words.iter().any(|word| text.contains(word))
    }

    /// Проверяет начало строки по целому слову, а не по совпадающему префиксу.
    fn starts_with_word(text: &str, word: &str) -> bool {
        text.starts_with(word)
            && text
                .chars()
                .nth(word.chars().count())
                .map(|c| !c.is_alphanumeric())
                .unwrap_or(true)
    }

    /// Сравнивает последовательность символов без учёта регистра.
    fn marker_matches(chars: &[char], start: usize, marker: &str) -> bool {
        let pattern: Vec<char> = marker.chars().collect();
        if start + pattern.len() > chars.len() {
            return false;
        }

        chars[start..start + pattern.len()]
            .iter()
            .zip(pattern.iter())
            .all(|(actual, expected)| actual.to_lowercase().to_string() == expected.to_string())
    }

    /// Проверяет, заканчивается ли маркер на границе слова.
    fn right_boundary(chars: &[char], end: usize) -> bool {
        end >= chars.len() || !chars[end].is_alphanumeric()
    }

    /// Пропускает пробелы, запятые и точки с запятой при разборе фразы.
    fn skip_spaces(chars: &[char], mut index: usize) -> usize {
        while index < chars.len() && (chars[index].is_whitespace() || matches!(chars[index], ',' | ';')) {
            index += 1;
        }
        index
    }

    /// Преобразует индекс символа (Unicode) в байтовую позицию строки UTF-8.
    fn byte_offset(text: &str, char_index: usize) -> usize {
        text.char_indices()
            .nth(char_index)
            .map(|(byte_index, _)| byte_index)
            .unwrap_or(text.len())
    }
}

// Проверки закрепляют правила последовательности, кавычек, местоимений
// и отказа от неоднозначных команд.
#[cfg(test)]
mod tests {
    use super::CommandParser;

    #[test]
    fn sequence_marker_keeps_second_file_on_desktop() {
        let result = CommandParser::parse_intent(
            "создай папку «важно», а потом сделай файл «счёт» на рабочем столе",
            &None,
        );

        assert_eq!(result.len(), 2);
        assert_eq!(result[0].0, "создать_папки");
        assert_eq!(result[0].1, vec!["важно".to_string()]);
        assert_eq!(result[1].0, "создать_файлы");
        assert_eq!(result[1].1, vec!["счёт".to_string(), String::new()]);
    }

    #[test]
    fn pronoun_after_and_places_file_inside_last_created_folder() {
        let result = CommandParser::parse_intent(
            "создай папку «неважно» и в неё сделай файл «хочу»",
            &None,
        );

        assert_eq!(result.len(), 2);
        assert_eq!(result[0].1, vec!["неважно".to_string()]);
        assert_eq!(result[1].1, vec!["неважно/хочу".to_string(), String::new()]);
    }

    #[test]
    fn omitted_verb_is_inherited_after_and() {
        let result = CommandParser::parse_intent("создай папку 'A' и файл 'B'", &None);

        assert_eq!(result.len(), 2);
        assert_eq!(result[0].0, "создать_папки");
        assert_eq!(result[1].0, "создать_файлы");
        assert_eq!(result[1].1, vec!["B".to_string(), String::new()]);
    }

    #[test]
    fn and_inside_quoted_name_is_not_a_separator() {
        let result = CommandParser::parse_intent("создай папку 'важное и срочное'", &None);

        assert_eq!(result.len(), 1);
        assert_eq!(result[0].1, vec!["важное и срочное".to_string()]);
    }

    #[test]
    fn multiple_names_after_one_verb_stay_in_one_operation() {
        let result = CommandParser::parse_intent("создай папки 'A' и 'B'", &None);

        assert_eq!(result.len(), 1);
        assert_eq!(result[0].0, "создать_папки");
        assert_eq!(result[0].1, vec!["A".to_string(), "B".to_string()]);
    }

    #[test]
    fn yo_and_e_pronoun_spellings_are_supported() {
        let context = Some("Проекты".to_string());
        let result = CommandParser::parse_intent("сделай файл 'план' в нее", &context);

        assert_eq!(result.len(), 1);
        assert_eq!(result[0].1, vec!["Проекты/план".to_string(), String::new()]);
    }

    #[test]
    fn different_destinations_in_one_clause_are_rejected() {
        let result = CommandParser::parse_intent(
            "сделай файл 'отчёт' в папке 'A' и в папке 'B'",
            &None,
        );
        assert!(result.is_empty());
    }

    #[test]
    fn unclear_second_part_prevents_partial_execution() {
        let result = CommandParser::parse_intent(
            "создай папку 'A', а потом в папке 'B'",
            &None,
        );
        assert!(result.is_empty());
    }

    #[test]
    fn unresolved_pronoun_is_not_assumed_to_mean_desktop() {
        let result = CommandParser::parse_intent("сделай файл 'план' в неё", &None);
        assert!(result.is_empty());
    }

    #[test]
    fn explicit_folder_destination_is_respected() {
        let result = CommandParser::parse_intent(
            "сделай файл 'план' в папке 'Учёба'",
            &None,
        );
        assert_eq!(result.len(), 1);
        assert_eq!(result[0].1, vec!["Учёба/план".to_string(), String::new()]);
    }

    #[test]
    fn explicit_destination_becomes_the_nearest_pronoun_reference() {
        let result = CommandParser::parse_intent(
            "сделай файл 'A' в папке 'Учёба', а потом сделай файл 'B' в ней",
            &None,
        );
        assert_eq!(result.len(), 2);
        assert_eq!(result[0].1, vec!["Учёба/A".to_string(), String::new()]);
        assert_eq!(result[1].1, vec!["Учёба/B".to_string(), String::new()]);
    }

    #[test]
    fn first_then_and_omitted_verb_are_supported() {
        let result = CommandParser::parse_intent(
            "сначала создай папку 'A', потом файл 'B'",
            &None,
        );
        assert_eq!(result.len(), 2);
        assert_eq!(result[0].0, "создать_папки");
        assert_eq!(result[1].0, "создать_файлы");
        assert_eq!(result[1].1, vec!["B".to_string(), String::new()]);
    }

    #[test]
    fn pronoun_location_can_omit_the_second_verb() {
        let result = CommandParser::parse_intent(
            "создай папку 'A' и в неё файл 'B'",
            &None,
        );
        assert_eq!(result.len(), 2);
        assert_eq!(result[1].1, vec!["A/B".to_string(), String::new()]);
    }
}
