//! Точка входа приложения и маршрутизация пользовательских команд.
//!
//! В обычном режиме Windows запускается графическое окно из `gui.rs`.
//! Оно открывает второй экземпляр того же EXE с аргументом `--worker`.
//! Рабочий процесс получает строки через stdin, распознаёт команды и
//! возвращает ответы через stdout/stderr. Аргумент `--cleanup` зарезервирован
//! для временного помощника, который завершает самоудаление приложения.
//! Само распознавание команд выполняется локальным кодом проекта — внешняя
//! языковая модель или облачный API в этой версии не используются.

#![cfg_attr(all(windows, not(test)), windows_subsystem = "windows")]

#[cfg(windows)]
mod gui;

mod file_manager;
mod hotkey;
mod network_control;
mod parser;
mod pc_info;
mod system_control;
mod self_uninstall;

use file_manager::FileManager;
use hotkey::{HotkeyCommand, HotkeyService, HotkeySpec};
use network_control::{NetworkCommand, NetworkControl};
use parser::CommandParser;
use pc_info::PcInfo;
use system_control::SystemControl;
use std::io::{self, Write};

/// Выбирает режим запуска: очистка после удаления, скрытый обработчик или GUI.
/// В Windows пользователь обычно попадает в графический интерфейс.
fn main() {
    // Временная копия EXE выполняет только задачу очистки после удаления.
    if self_uninstall::run_cleanup_mode() {
        return;
    }

    let worker_mode = std::env::args().any(|arg| arg == "--worker");
    if worker_mode {
        run_worker();
        return;
    }

    #[cfg(windows)]
    {
        if let Err(error) = gui::run() {
            gui::show_fatal_error(&error);
        }
    }

    #[cfg(not(windows))]
    {
        eprintln!("Графическая версия ассистента доступна только в Windows.");
        run_worker();
    }
}

/// Запускает цикл скрытого обработчика команд. GUI создаёт этот процесс,
/// передаёт пользовательский ввод через stdin и получает ответы через stdout/stderr.
/// Здесь команды проходят последовательно через специализированные модули:
/// горячие клавиши, сведения о ПК, сеть, системные настройки, затем файлы.
/// GUI запускает эту функцию в дочернем процессе, но её stdin/stdout связаны
/// с полем ввода и историей сообщений главного окна.
fn run_worker() {
    println!("=== Локальный ИИ-ассистент: обработчик команд ===");
    CommandParser::print_help();
    print_system_help();

    let (mut active_hotkey, config_warning) = hotkey::load_or_default();
    if let Some(warning) = config_warning {
        println!("⚠️ {warning}");
    }
    // Глобальная горячая клавиша регистрируется главным GUI-процессом.
    // Дочерний обработчик не должен занимать то же сочетание второй раз.
    let hotkey_service: Option<HotkeyService> = None;
    println!("Обработчик команд готов и ожидает ввод от графического интерфейса.");

    let mut last_created_folder: Option<String> = None;
    let mut awaiting_hotkey_value = false;

    loop {
        print!("\nВы> ");
        if io::stdout().flush().is_err() {
            eprintln!("Не удалось обновить консольный вывод.");
        }

        let mut input = String::new();
        if io::stdin().read_line(&mut input).is_err() {
            println!("Ошибка чтения ввода.");
            continue;
        }

        let raw_input = input.trim();
        if raw_input.is_empty() {
            continue;
        }
        let layout_correction = maybe_correct_russian_keyboard_layout(raw_input);
        let input_trimmed = layout_correction.as_deref().unwrap_or(raw_input);
        if let Some(corrected) = layout_correction.as_deref() {
            println!("(Распознал русскую команду в английской раскладке: {corrected})");
        }

        if awaiting_hotkey_value {
            if matches!(input_trimmed.to_lowercase().as_str(), "отмена" | "cancel") {
                awaiting_hotkey_value = false;
                println!("Изменение горячей клавиши отменено.");
                continue;
            }
            match HotkeySpec::parse(input_trimmed) {
                Ok(next_spec) => {
                    awaiting_hotkey_value = false;
                    match apply_hotkey_spec(next_spec, &mut active_hotkey, hotkey_service.as_ref()) {
                        Ok(message) => println!("ИИ-Ассистент: {message}"),
                        Err(error) => println!("Не удалось изменить горячую клавишу: {error}"),
                    }
                }
                Err(error) => {
                    println!("{error}");
                    println!("Введи сочетание, например Ctrl+Alt+K, или напиши «отмена».");
                }
            }
            continue;
        }

        if input_trimmed.eq_ignore_ascii_case("выход")
            || input_trimmed.eq_ignore_ascii_case("exit")
        {
            println!("ИИ-Ассистент: До свидания!");
            break;
        }

        if input_trimmed.eq_ignore_ascii_case("cargo test")
            || input_trimmed.eq_ignore_ascii_case("cargo run")
            || input_trimmed.eq_ignore_ascii_case("cargo build --release")
        {
            println!("Это команда для терминала VS Code, а не для строки «Вы>» внутри ассистента. Введи «выход», затем выполни {input_trimmed} в терминале, открытом в папке с Cargo.toml.");
            continue;
        }

        if input_trimmed.eq_ignore_ascii_case("помощь")
            || input_trimmed.eq_ignore_ascii_case("help")
        {
            CommandParser::print_help();
            print_system_help();
            continue;
        }

        // Пользовательская горячая клавиша и её сохранение.
        if let Some(command) = hotkey::parse_command(input_trimmed) {
            match command {
                HotkeyCommand::Show => {
                    println!("ИИ-Ассистент: Текущая горячая клавиша — {}.", active_hotkey.label);
                }
                HotkeyCommand::PromptForValue => {
                    if hotkey_service.is_none() {
                        println!("Обработчик горячих клавиш не запущен, поэтому изменить сочетание сейчас нельзя.");
                    } else {
                        awaiting_hotkey_value = true;
                        println!("Введи новое сочетание, например Ctrl+Alt+K. Для отмены напиши «отмена».");
                    }
                }
                HotkeyCommand::Set(raw_spec) => match HotkeySpec::parse(&raw_spec) {
                    Ok(next_spec) => {
                        match apply_hotkey_spec(next_spec, &mut active_hotkey, hotkey_service.as_ref()) {
                            Ok(message) => println!("ИИ-Ассистент: {message}"),
                            Err(error) => println!("Не удалось изменить горячую клавишу: {error}"),
                        }
                    }
                    Err(error) => println!("ИИ-Ассистент: {error}"),
                },
            }
            continue;
        }

        // Запросы системной информации — только чтение, они не меняют настройки.
        if PcInfo::is_info_request(input_trimmed) {
            match PcInfo::get_info() {
                Ok(info) => println!("ИИ-Ассистент:\n{info}"),
                Err(error) => eprintln!("❌ Не удалось получить информацию о ПК: {error}"),
            }
            continue;
        }

        // Сеть: просмотр адаптеров/подключений и явное управление адаптером.
        match NetworkControl::parse_command(input_trimmed) {
            Ok(Some(command)) => {
                if let NetworkCommand::SetAdapterEnabled { name, enabled: false } = &command {
                    println!("⚠️ Отключение адаптера «{name}» может разорвать подключение к Интернету.");
                    println!("Для подтверждения введи ДА:");
                    let _ = io::stdout().flush();
                    let mut confirmation = String::new();
                    if io::stdin().read_line(&mut confirmation).is_err()
                        || !matches!(confirmation.trim().to_lowercase().as_str(), "да" | "подтверждаю")
                    {
                        println!("Операция отменена.");
                        continue;
                    }
                }

                match NetworkControl::execute(command) {
                    Ok(message) => println!("ИИ-Ассистент:\n{message}"),
                    Err(error) => eprintln!("❌ Ошибка сетевой команды: {error}"),
                }
                continue;
            }
            Ok(None) => {}
            Err(error) => {
                println!("ИИ-Ассистент: {error}");
                continue;
            }
        }

        // Команды громкости и яркости.
        match SystemControl::parse_command(input_trimmed) {
            Ok(Some(command)) => {
                match SystemControl::execute(command) {
                    Ok(message) => println!("ИИ-Ассистент: {message}"),
                    Err(error) => eprintln!("❌ Ошибка системной команды: {error}"),
                }
                continue;
            }
            Ok(None) => {}
            Err(error) => {
                println!("ИИ-Ассистент: {error}");
                continue;
            }
        }

        // Далее идут уже существующие файловые команды.
        let intents = CommandParser::parse_intent(input_trimmed, &last_created_folder);
        if intents.is_empty() {
            println!("Не удалось однозначно разобрать команду. Уточните действие, название объекта или место назначения.");
            continue;
        }

        for (action, args) in intents {
            let mut action_succeeded = true;

            // Парсер возвращает уже упорядоченный список намерений. Выполняем
            // их строго по порядку и прекращаем остаток цепочки при первой ошибке.
            match action.as_str() {
                // Относительные пути разрешаются файловым модулем относительно рабочего стола.
                "создать_папки" => {
                    for path in &args {
                        if let Err(error) = FileManager::create_dir(path) {
                            eprintln!("❌ Ошибка: {error}");
                            action_succeeded = false;
                            break;
                        } else {
                            last_created_folder = Some(path.clone());
                            println!("Сделал папку '{}'", path);
                        }
                    }
                }
                // У команды создания файла последний аргумент зарезервирован под текст,
                // а все предыдущие элементы — пути создаваемых файлов.
                "создать_файлы" => {
                    if args.is_empty() {
                        eprintln!("❌ Ошибка: парсер передал пустую команду создания файла.");
                        action_succeeded = false;
                    } else {
                        let (file_paths, content) = args.split_at(args.len() - 1);
                        let text_to_write = &content[0];
                        for path in file_paths {
                            if let Err(error) = FileManager::create_file(path, text_to_write) {
                                eprintln!("❌ Ошибка: {error}");
                                action_succeeded = false;
                                break;
                            } else {
                                if let Some(parent) = std::path::Path::new(path).parent() {
                                    let parent = parent.to_string_lossy().to_string();
                                    if !parent.is_empty() {
                                        last_created_folder = Some(parent);
                                    }
                                }
                                if text_to_write.is_empty() {
                                    println!("Сделал файл '{}'", path);
                                } else {
                                    println!("Сделал файл '{}' с текстом: \"{}\"", path, text_to_write);
                                }
                            }
                        }
                    }
                }
                // Очистка удаляет содержимое выбранной папки, но оставляет саму папку.
                "очистить_папку" => {
                    if args.is_empty() {
                        eprintln!("❌ Ошибка: не указана папка для очистки.");
                        action_succeeded = false;
                    } else {
                        let dir_path = &args[0];
                        match FileManager::delete_all_in_dir(dir_path) {
                            Ok(_) => {
                                last_created_folder = Some(dir_path.clone());
                                println!("Очистил все файлы в папке '{}'", dir_path);
                            }
                            Err(error) => {
                                eprintln!("❌ Ошибка очистки папки: {error}");
                                action_succeeded = false;
                            }
                        }
                    }
                }
                // Удаление выполняется без корзины Windows; путь передан явно парсером.
                "удалить_много" => {
                    for target in &args {
                        match FileManager::delete_item(target) {
                            Ok(_) => println!("Удалил '{}'", target),
                            Err(error) => {
                                eprintln!("❌ Ошибка удаления '{}': {error}", target);
                                action_succeeded = false;
                                break;
                            }
                        }
                        if Some(target.clone()) == last_created_folder {
                            last_created_folder = None;
                        }
                    }
                }
                // Один и тот же вызов файлового API используется для переименования
                // внутри каталога и перемещения в другое место.
                "переименовать" => {
                    if args.len() < 2 {
                        eprintln!("❌ Ошибка: недостаточно аргументов для переименования.");
                        action_succeeded = false;
                    } else {
                        let old_path = &args[0];
                        let new_path = &args[1];
                        if let Err(error) = FileManager::rename_or_move(old_path, new_path) {
                            eprintln!("❌ Ошибка: {error}");
                            action_succeeded = false;
                        } else {
                            println!("Сделал. Переименовано в '{}'", new_path);
                            if Some(old_path.clone()) == last_created_folder {
                                last_created_folder = Some(new_path.clone());
                            }
                        }
                    }
                }
                _ => {
                    println!("Извините, я не понял эту часть команды");
                    action_succeeded = false;
                }
            }

            if !action_succeeded {
                println!("Остановил оставшиеся действия команды из-за ошибки.");
                break;
            }
        }
    }
}

/// Печатает примеры команд для модулей Windows, сети и управления приложением.
fn print_system_help() {
    println!("\n=== СИСТЕМА И СЕТЬ ===");
    println!("  • Информация о компьютере / характеристики ПК");
    println!("  • Какая сеть? / Состояние сети");
    println!("  • Покажи сетевые адаптеры");
    println!("  • Отключи сетевой адаптер «Wi-Fi»");
    println!("  • Включи сетевой адаптер «Wi-Fi»");
    println!("  • Какая горячая клавиша? / Гор. клавиши");
    println!("  • Поменяй гор. клавиши (затем введи Ctrl+Alt+K)");
    println!("  • Или сразу: Измени гор. клавиши на Ctrl+Alt+K");
    println!("  • Для удаления приложения: «самоуничтожение» (потребуется точное подтверждение)");
    println!("  • Яркость 60 / А яркость? / Громкость 30\n");
}


/// Обновляет сочетание через `HotkeyService` и сохраняет его в профиле.
/// При ошибке записи пытается вернуть предыдущее активное сочетание.
/// В текущем графическом сценарии горячей клавишей управляет `gui.rs`.
fn apply_hotkey_spec(
    next_spec: HotkeySpec,
    active_hotkey: &mut HotkeySpec,
    hotkey_service: Option<&HotkeyService>,
) -> Result<String, String> {
    let service = hotkey_service
        .ok_or_else(|| "обработчик горячих клавиш не запущен".to_string())?;
    let previous = active_hotkey.clone();

    service.update(next_spec.clone())?;
    match hotkey::save(&next_spec) {
        Ok(()) => {
            *active_hotkey = next_spec;
            Ok(format!("Горячая клавиша изменена на {} и сохранена.", active_hotkey.label))
        }
        Err(error) => {
            let rollback = service.update(previous.clone());
            if let Err(rollback_error) = rollback {
                Err(format!("Не удалось сохранить настройку: {error}. Не удалось также вернуть прежнее сочетание: {rollback_error}"))
            } else {
                Err(format!("Не удалось сохранить настройку: {error}. Вернул прежнее сочетание {}.", previous.label))
            }
        }
    }
}

/// Исправляет только явно распознаваемые русские команды, набранные
/// при включённой английской раскладке. Остальной текст не трогает.
/// Исправляет распространённые команды, набранные при включённой английской
/// раскладке. Случайный английский текст не переводится: сначала проверяется,
/// похож ли результат на известную русскую команду.
pub(crate) fn maybe_correct_russian_keyboard_layout(input: &str) -> Option<String> {
    if !input.is_ascii() {
        return None;
    }

    let from = "qwertyuiop[]asdfghjkl;'zxcvbnm,./";
    let to = "йцукенгшщзхъфывапролджэячсмитьбю.";
    let translated: String = input
        .chars()
        .map(|ch| {
            let lower = ch.to_ascii_lowercase();
            if let Some(index) = from.find(lower) {
                to.chars().nth(index).unwrap_or(ch)
            } else {
                ch
            }
        })
        .collect();

    let normalized = translated.to_lowercase();
    let recognized = matches!(normalized.trim(), "помощь" | "выход" | "а яркость" | "а яркость?" | "а громкость" | "а громкость?")
        || [
            "создай ", "сделай ", "удали ", "удалить ", "переименуй ",
            "перемести ", "очисти ", "громкость", "яркость", "какая ",
            "покажи ", "информация о ", "характеристики ", "состояние сети",
            "поменяй горячую клавишу", "измени горячую клавишу",
            "включи ", "выключи ",
        ]
        .iter()
        .any(|prefix| normalized.starts_with(prefix));

    recognized.then_some(translated)
}

#[cfg(test)]
mod main_input_tests {
    use super::maybe_correct_russian_keyboard_layout;

    #[test]
    fn corrects_help_typed_in_english_layout() {
        assert_eq!(maybe_correct_russian_keyboard_layout("gjvjom"), Some("помощь".to_string()));
    }

    #[test]
    fn corrects_short_brightness_question_in_english_layout() {
        assert_eq!(maybe_correct_russian_keyboard_layout("f zhrjcnm?"), Some("а яркость?".to_string()));
    }

    #[test]
    fn does_not_rewrite_unrecognized_english_text() {
        assert_eq!(maybe_correct_russian_keyboard_layout("cargo test"), None);
    }
}
