//! Получение базовой информации о компьютере через встроенные Windows CIM/WMI.
//!
//! Сведения собираются PowerShell-командой и передаются в Rust как JSON.
//! Отчёт включает модель устройства, ОС, CPU, GPU, RAM и заряд батареи,
//! если соответствующее оборудование/поле доступно системе.

use serde_json::Value;
use std::process::Command;

/// Распознаёт запросы характеристик ПК и формирует отчёт о системе.
pub struct PcInfo;

impl PcInfo {
    /// Определяет, просит ли пользователь показать сведения о компьютере.
    pub fn is_info_request(input: &str) -> bool {
        let normalized = input.trim().to_lowercase().replace('ё', "е");
        let text = remove_quoted_text(&normalized)
            .trim_end_matches(|ch| matches!(ch, '?' | '!' | '.'))
            .trim()
            .to_string();
        [
            "информация о компьютере",
            "покажи информацию о компьютере",
            "покажи сведения о компьютере",
            "информация о пк",
            "характеристики компьютера",
            "характеристики пк",
            "характеристики системы",
            "какой у меня компьютер",
            "что внутри пк",
            "сведения о системе",
            "информация о системе",
            "покажи характеристики",
            "что за компьютер",
            "информация о моем компьютере",
        ]
        .iter()
        .any(|phrase| text == *phrase || text.starts_with(&format!("{phrase} ")))
    }

    /// Получает сведения из CIM/WMI и форматирует их в русскоязычный отчёт.
    /// Отсутствующая батарея или видеокарта не считается критической ошибкой.
    pub fn get_info() -> Result<String, String> {
        let script = r#"
$ErrorActionPreference = 'Stop'
$utf8 = [System.Text.UTF8Encoding]::new($false)
[Console]::OutputEncoding = $utf8
$OutputEncoding = $utf8
try {
    $os = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop
    $computer = Get-CimInstance Win32_ComputerSystem -ErrorAction Stop
    $cpu = Get-CimInstance Win32_Processor -ErrorAction Stop | Select-Object -First 1
    $gpu = Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue | Select-Object -First 1
    $battery = Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue | Select-Object -First 1
    $batteryPercent = $null
    if ($null -ne $battery) { $batteryPercent = [int]$battery.EstimatedChargeRemaining }
    $result = [pscustomobject]@{
        ComputerName = [string]$computer.Name
        Manufacturer = [string]$computer.Manufacturer
        Model = [string]$computer.Model
        Windows = [string]$os.Caption
        WindowsVersion = [string]$os.Version
        Build = [string]$os.BuildNumber
        Cpu = [string]$cpu.Name
        CpuCores = [int]$cpu.NumberOfCores
        CpuThreads = [int]$cpu.NumberOfLogicalProcessors
        Gpu = if ($null -ne $gpu) { [string]$gpu.Name } else { '' }
        TotalRamGB = [math]::Round(([double]$computer.TotalPhysicalMemory / 1GB), 1)
        FreeRamGB = [math]::Round(([double]$os.FreePhysicalMemory * 1KB / 1GB), 1)
        BatteryPercent = $batteryPercent
    }
    ConvertTo-Json -InputObject $result -Compress -Depth 4
} catch {
    [Console]::Out.WriteLine('ERROR:' + $_.Exception.Message)
    exit 1
}
"#;
        let output = run_powershell(script)?;
        let value: Value = serde_json::from_str(&output)
            .map_err(|error| format!("Не удалось разобрать сведения о ПК: {error}. Ответ: {output}"))?;

        let mut lines = vec!["Информация о компьютере:".to_string()];
        push_line(&mut lines, "Имя", &value["ComputerName"]);
        push_line(&mut lines, "Производитель", &value["Manufacturer"]);
        push_line(&mut lines, "Модель", &value["Model"]);
        push_line(&mut lines, "Операционная система", &value["Windows"]);
        push_line(&mut lines, "Версия Windows", &value["WindowsVersion"]);
        push_line(&mut lines, "Сборка", &value["Build"]);
        push_line(&mut lines, "Процессор", &value["Cpu"]);
        if let (Some(cores), Some(threads)) = (value["CpuCores"].as_u64(), value["CpuThreads"].as_u64()) {
            lines.push(format!("Ядра / логические потоки: {cores} / {threads}"));
        }
        push_line(&mut lines, "Видеокарта", &value["Gpu"]);
        if let (Some(total), Some(free)) = (value["TotalRamGB"].as_f64(), value["FreeRamGB"].as_f64()) {
            lines.push(format!("Оперативная память: {total:.1} ГБ всего, {free:.1} ГБ свободно"));
        }
        if let Some(battery) = value["BatteryPercent"].as_u64() {
            lines.push(format!("Батарея: {battery}%"));
        } else {
            lines.push("Батарея: не обнаружена (возможно, настольный ПК)".to_string());
        }
        Ok(lines.join("\n"))
    }
}

/// Не позволяет словам внутри имени файла активировать команду сведений о ПК.
fn remove_quoted_text(text: &str) -> String {
    let mut result = String::with_capacity(text.len());
    let mut closing_quote: Option<char> = None;
    for ch in text.chars() {
        if let Some(end) = closing_quote {
            result.push(' ');
            if ch == end { closing_quote = None; }
        } else {
            match ch {
                '\'' => { closing_quote = Some('\''); result.push(' '); }
                '"' => { closing_quote = Some('"'); result.push(' '); }
                '«' => { closing_quote = Some('»'); result.push(' '); }
                '„' => { closing_quote = Some('“'); result.push(' '); }
                '“' => { closing_quote = Some('”'); result.push(' '); }
                _ => result.push(ch),
            }
        }
    }
    result
}

/// Добавляет строку отчёта только когда соответствующее поле JSON непустое.
fn push_line(lines: &mut Vec<String>, label: &str, value: &Value) {
    if let Some(value) = value.as_str().filter(|value| !value.trim().is_empty()) {
        lines.push(format!("{label}: {value}"));
    }
}

/// Запускает запрос CIM через PowerShell и возвращает результат либо понятную ошибку.
fn run_powershell(script: &str) -> Result<String, String> {
    let output = Command::new("powershell.exe")
        .args(["-NoLogo", "-NoProfile", "-NonInteractive", "-Command", script])
        .output()
        .map_err(|error| format!("Не удалось запустить PowerShell: {error}"))?;
    let stdout = String::from_utf8_lossy(&output.stdout).trim().to_string();
    if output.status.success() {
        if let Some(error) = stdout.strip_prefix("ERROR:") {
            return Err(error.trim().to_string());
        }
        Ok(stdout)
    } else {
        Err(stdout
            .strip_prefix("ERROR:")
            .map(str::trim)
            .filter(|s| !s.is_empty())
            .unwrap_or("Не удалось получить сведения о компьютере.")
            .to_string())
    }
}

#[cfg(test)]
mod tests {
    use super::PcInfo;

    #[test]
    fn recognizes_pc_information_phrases() {
        assert!(PcInfo::is_info_request("Покажи характеристики ПК"));
        assert!(PcInfo::is_info_request("Информация о компьютере"));
        assert!(!PcInfo::is_info_request("создай файл 'информация о пк'"));
    }
}
