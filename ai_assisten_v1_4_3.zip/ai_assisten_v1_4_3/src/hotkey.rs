//! Разбор, хранение и регистрация пользовательской горячей клавиши.
//!
//! В графической версии Win32-регистрацию привязывает к главному окну модуль
//! `gui.rs`. Файл также содержит потоковый сервис для альтернативного режима.
//! Подпись сочетания хранится в конфигурационном каталоге пользователя Windows.

use std::path::PathBuf;
use std::sync::mpsc::{self, Sender, SyncSender};
use std::thread::JoinHandle;
#[cfg(windows)]
use std::thread;
use std::time::Duration;

/// Нормализованное сочетание: подпись для интерфейса, модификаторы и виртуальный код клавиши.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct HotkeySpec {
    /// Каноническое название для интерфейса и сохранения в настройках.
    pub label: String,
    /// Флаги модификаторов Windows: Ctrl, Alt, Shift и/или Win.
    pub modifiers: u32,
    /// Виртуальный код основной клавиши Windows.
    pub virtual_key: u32,
}

impl HotkeySpec {
    /// Проверяет строку вида `Ctrl+Alt+K` и преобразует её в формат Windows.
    /// Повторяющиеся модификаторы и несколько основных клавиш запрещены.
    pub fn parse(input: &str) -> Result<Self, String> {
        let mut modifiers = 0u32;
        let mut key: Option<(u32, String)> = None;
        let mut seen_modifiers = Vec::new();

        for raw_part in input.split('+') {
            let part = raw_part.trim();
            if part.is_empty() {
                return Err("В сочетании есть пустая часть. Пример: Ctrl+Alt+Space.".to_string());
            }
            let normalized = part.to_ascii_lowercase();
            let modifier = match normalized.as_str() {
                "ctrl" | "control" => Some((0x0002, "Ctrl")),
                "alt" => Some((0x0001, "Alt")),
                "shift" => Some((0x0004, "Shift")),
                "win" | "windows" => Some((0x0008, "Win")),
                _ => None,
            };

            if let Some((bit, label)) = modifier {
                if modifiers & bit != 0 {
                    return Err(format!("Модификатор {label} указан дважды."));
                }
                modifiers |= bit;
                seen_modifiers.push(label.to_string());
            } else if key.is_none() {
                key = Some(parse_key(part)?);
            } else {
                return Err("Укажи только одну основную клавишу. Пример: Ctrl+Alt+K.".to_string());
            }
        }

        if modifiers == 0 {
            return Err("Для глобальной горячей клавиши добавь Ctrl, Alt, Shift или Win.".to_string());
        }
        let (virtual_key, key_label) = key.ok_or_else(|| {
            "Не указана основная клавиша. Пример: Ctrl+Alt+Space.".to_string()
        })?;

        let mut label_parts = Vec::new();
        for name in ["Ctrl", "Alt", "Shift", "Win"] {
            if seen_modifiers.iter().any(|item| item == name) {
                label_parts.push(name.to_string());
            }
        }
        label_parts.push(key_label);

        Ok(Self {
            label: label_parts.join("+"),
            modifiers,
            virtual_key,
        })
    }

    /// Возвращает сочетание, используемое при первом запуске: Ctrl+Alt+Space.
    pub fn default_spec() -> Self {
        Self::parse("Ctrl+Alt+Space").expect("default hotkey is valid")
    }
}

/// Сопоставляет имя основной клавиши с Windows virtual-key code.
fn parse_key(input: &str) -> Result<(u32, String), String> {
    let key = input.trim();
    let upper = key.to_uppercase();

    if upper.len() == 1 {
        let byte = upper.as_bytes()[0];
        if byte.is_ascii_uppercase() || byte.is_ascii_digit() {
            return Ok((byte as u32, upper));
        }
    }

    if let Some(number) = upper.strip_prefix('F').and_then(|s| s.parse::<u32>().ok()) {
        if (1..=11).contains(&number) {
            return Ok((0x70 + number - 1, format!("F{number}")));
        }
        if number == 12 {
            return Err("F12 зарезервирована Windows и отладчиками. Выбери другую клавишу.".to_string());
        }
    }

    let pair = match upper.as_str() {
        "SPACE" | "ПРОБЕЛ" => (0x20, "Space"),
        "ENTER" | "RETURN" => (0x0D, "Enter"),
        "ESC" | "ESCAPE" => (0x1B, "Esc"),
        "TAB" => (0x09, "Tab"),
        "INSERT" | "INS" => (0x2D, "Insert"),
        "DELETE" | "DEL" => (0x2E, "Delete"),
        "HOME" => (0x24, "Home"),
        "END" => (0x23, "End"),
        "PAGEUP" | "PGUP" => (0x21, "PageUp"),
        "PAGEDOWN" | "PGDN" => (0x22, "PageDown"),
        "UP" => (0x26, "Up"),
        "DOWN" => (0x28, "Down"),
        "LEFT" => (0x25, "Left"),
        "RIGHT" => (0x27, "Right"),
        _ => return Err(format!("Неизвестная клавиша «{key}». Поддерживаются A–Z, 0–9, F1–F11, Space, Enter, Esc и стрелки.")),
    };
    Ok((pair.0, pair.1.to_string()))
}

/// Команды управления сочетанием, распознанные из русской фразы.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum HotkeyCommand {
    /// Показать действующее сочетание.
    Show,
    /// Запросить у пользователя новое сочетание отдельной строкой.
    PromptForValue,
    /// Установить сочетание, указанное непосредственно в исходной фразе.
    Set(String),
}

/// Нормализует разговорные названия «горячей клавиши», включая сокращение «гор.».
/// Вопросительные формулировки приводятся к именительному падежу,
/// а команды изменения — к винительному.
fn normalize_hotkey_command(input: &str) -> String {
    let mut value = input
        .to_lowercase()
        .replace('ё', "е")
        .trim_end_matches(|ch| matches!(ch, '?' | '!' | '.'))
        .trim()
        .to_string();

    let action_context = ["поменяй ", "измени ", "установи ", "назначь ", "хочу поменять ", "хочу изменить "]
        .iter()
        .any(|prefix| value.starts_with(prefix));
    let replacement = if action_context { "горячую клавишу" } else { "горячая клавиша" };

    for short in ["гор. клавиши", "гор.клавиши", "гор клавиши", "гор. клавишу", "гор.клавишу", "гор клавишу"] {
        value = value.replace(short, replacement);
    }
    for short in ["гор. клавиша", "гор.клавиша", "гор клавиша"] {
        value = value.replace(short, "горячая клавиша");
    }
    value
}

/// Превращает фразу пользователя в просмотр, запрос нового значения или установку хоткея.
pub fn parse_command(input: &str) -> Option<HotkeyCommand> {
    let trimmed = input.trim();
    let lower = normalize_hotkey_command(trimmed);

    if matches!(
        lower.as_str(),
        "горячая клавиша"
            | "какая горячая клавиша"
            | "покажи горячую клавишу"
            | "какое сочетание клавиш"
            | "покажи сочетание клавиш"
    ) {
        return Some(HotkeyCommand::Show);
    }

    if matches!(
        lower.as_str(),
        "поменяй горячую клавишу"
            | "измени горячую клавишу"
            | "хочу поменять горячую клавишу"
            | "хочу изменить горячую клавишу"
            | "поменяй сочетание клавиш"
            | "измени сочетание клавиш"
    ) {
        return Some(HotkeyCommand::PromptForValue);
    }

    for prefix in [
        "измени горячую клавишу на ",
        "поменяй горячую клавишу на ",
        "установи горячую клавишу ",
        "установи горячую клавишу на ",
        "назначь горячую клавишу ",
        "измени сочетание на ",
        "поменяй сочетание на ",
        "поменяй сочетание клавиш на ",
        "измени сочетание клавиш на ",
    ] {
        if lower.starts_with(prefix) {
            // Берём хвост из нормализованной строки: сокращение «гор.»
            // расширяется и поэтому длина префикса отличается от исходной.
            let value = lower[prefix.len()..]
                .trim()
                .trim_end_matches(|ch| matches!(ch, '?' | '!' | '.'))
                .trim();
            if !value.is_empty() {
                // Return a canonical, human-readable label when the value is valid.
                // The command parser lowercases text for matching, but the hotkey
                // parser can restore the conventional Ctrl+Alt+K presentation.
                let canonical = HotkeySpec::parse(value)
                    .map(|spec| spec.label)
                    .unwrap_or_else(|_| value.to_string());
                return Some(HotkeyCommand::Set(canonical));
            }
        }
    }

    None
}

/// Загружает сочетание из профиля пользователя или возвращает значение по умолчанию.
pub fn load_or_default() -> (HotkeySpec, Option<String>) {
    let path = match settings_path() {
        Ok(path) => path,
        Err(error) => return (HotkeySpec::default_spec(), Some(error)),
    };

    if !path.exists() {
        return (HotkeySpec::default_spec(), None);
    }

    match std::fs::read_to_string(&path) {
        Ok(value) => match HotkeySpec::parse(value.trim()) {
            Ok(spec) => (spec, None),
            Err(error) => (
                HotkeySpec::default_spec(),
                Some(format!("Сохранённая горячая клавиша некорректна ({error}). Использую Ctrl+Alt+Space.")),
            ),
        },
        Err(error) => (
            HotkeySpec::default_spec(),
            Some(format!("Не удалось прочитать настройки горячей клавиши: {error}")),
        ),
    }
}

/// Сохраняет нормализованную подпись сочетания в пользовательский конфигурационный файл.
pub fn save(spec: &HotkeySpec) -> Result<(), String> {
    let path = settings_path()?;
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent)
            .map_err(|error| format!("Не удалось создать папку настроек: {error}"))?;
    }
    std::fs::write(path, format!("{}\n", spec.label))
        .map_err(|error| format!("Не удалось сохранить горячую клавишу: {error}"))
}

/// Определяет путь настроек в каталоге конфигурации текущего пользователя.
fn settings_path() -> Result<PathBuf, String> {
    let project = directories::ProjectDirs::from("com", "LocalAI", "Assistant")
        .ok_or_else(|| "Не удалось определить папку настроек пользователя.".to_string())?;
    Ok(project.config_dir().join("hotkey.txt"))
}

/// Потоковый сервис регистрации хоткея для альтернативного консольного режима.
pub struct HotkeyService {
    sender: Sender<HotkeyMessage>,
    worker: Option<JoinHandle<()>>,
}

/// Внутренние сообщения потоку сервиса: обновить сочетание или завершиться.
enum HotkeyMessage {
    Update(HotkeySpec, SyncSender<Result<(), String>>),
    Shutdown,
}

impl HotkeyService {
    /// Запускает платформенный поток и ждёт подтверждения первой регистрации.
    pub fn start(initial: HotkeySpec) -> Result<Self, String> {
        #[cfg(windows)]
        {
            let (sender, receiver) = mpsc::channel();
            let (ready_sender, ready_receiver) = mpsc::sync_channel(1);
            let worker = thread::spawn(move || windows_platform::run(initial, receiver, ready_sender));
            match ready_receiver.recv_timeout(Duration::from_secs(5)) {
                Ok(Ok(())) => Ok(Self { sender, worker: Some(worker) }),
                Ok(Err(error)) => {
                    let _ = worker.join();
                    Err(error)
                }
                Err(error) => Err(format!("Не удалось запустить обработчик горячей клавиши: {error}")),
            }
        }
        #[cfg(not(windows))]
        {
            let _ = initial;
            Err("Глобальные горячие клавиши в этой сборке доступны только на Windows.".to_string())
        }
    }

    /// Просит рабочий поток заменить сочетание и ждёт результата регистрации.
    pub fn update(&self, spec: HotkeySpec) -> Result<(), String> {
        let (reply_sender, reply_receiver) = mpsc::sync_channel(1);
        self.sender
            .send(HotkeyMessage::Update(spec, reply_sender))
            .map_err(|_| "Обработчик горячих клавиш уже остановлен.".to_string())?;
        reply_receiver
            .recv_timeout(Duration::from_secs(3))
            .map_err(|error| format!("Не получен ответ обработчика горячих клавиш: {error}"))?
    }
}

// При уничтожении сервиса отправляем команду завершения и дожидаемся потока.
impl Drop for HotkeyService {
    fn drop(&mut self) {
        let _ = self.sender.send(HotkeyMessage::Shutdown);
        if let Some(worker) = self.worker.take() {
            let _ = worker.join();
        }
    }
}

#[cfg(windows)]
mod windows_platform {
    use super::{HotkeyMessage, HotkeySpec};
    use std::sync::mpsc::{Receiver, SyncSender, TryRecvError};
    use std::thread;
    use std::time::Duration;
    use windows::Win32::System::Console::GetConsoleWindow;
    use windows::Win32::UI::Input::KeyboardAndMouse::{
        RegisterHotKey, UnregisterHotKey, HOT_KEY_MODIFIERS,
    };
    use windows::Win32::UI::WindowsAndMessaging::{
        PeekMessageW, SetForegroundWindow, ShowWindow, MSG, PM_REMOVE, SW_RESTORE, WM_HOTKEY,
    };

    const HOTKEY_ID: i32 = 0x4A31;

    /// Поток Windows: регистрирует сочетание, читает WM_HOTKEY и принимает обновления.
    pub fn run(
        initial: HotkeySpec,
        receiver: Receiver<HotkeyMessage>,
        ready: SyncSender<Result<(), String>>,
    ) {
        let mut current = initial;
        // Явно создаём очередь сообщений этого потока до регистрации хоткея.
        unsafe {
            let mut initial_message = MSG::default();
            let _ = PeekMessageW(&mut initial_message, None, 0, 0, PM_REMOVE);
        }
        if let Err(error) = register(&current) {
            let _ = ready.send(Err(error));
            return;
        }
        let _ = ready.send(Ok(()));

        loop {
            pump_messages();
            match receiver.try_recv() {
                Ok(HotkeyMessage::Update(next, response)) => {
                    let _ = unsafe { UnregisterHotKey(None, HOTKEY_ID) };
                    match register(&next) {
                        Ok(()) => {
                            current = next;
                            let _ = response.send(Ok(()));
                        }
                        Err(error) => {
                            let restore = register(&current);
                            let message = if let Err(restore_error) = restore {
                                format!("{error}. Не удалось восстановить прежнее сочетание: {restore_error}")
                            } else {
                                error
                            };
                            let _ = response.send(Err(message));
                        }
                    }
                }
                Ok(HotkeyMessage::Shutdown) => break,
                Err(TryRecvError::Disconnected) => break,
                Err(TryRecvError::Empty) => {}
            }
            thread::sleep(Duration::from_millis(20));
        }
        let _ = unsafe { UnregisterHotKey(None, HOTKEY_ID) };
    }

    /// Регистрирует сочетание через Windows RegisterHotKey с защитой от автоповтора.
    fn register(spec: &HotkeySpec) -> Result<(), String> {
        let modifiers = HOT_KEY_MODIFIERS(spec.modifiers | 0x4000); // MOD_NOREPEAT
        unsafe { RegisterHotKey(None, HOTKEY_ID, modifiers, spec.virtual_key) }
            .map_err(|error| format!("Не удалось зарегистрировать {}. Возможно, это сочетание уже занято другой программой. Детали Windows: {error}", spec.label))
    }

    /// Вычитывает очередь сообщений потока и реагирует на зарегистрированный хоткей.
    fn pump_messages() {
        unsafe {
            let mut message = MSG::default();
            while PeekMessageW(&mut message, None, 0, 0, PM_REMOVE).as_bool() {
                if message.message == WM_HOTKEY && message.wParam.0 as i32 == HOTKEY_ID {
                    let window = GetConsoleWindow();
                    if !window.0.is_null() {
                        let _ = ShowWindow(window, SW_RESTORE);
                        let _ = SetForegroundWindow(window);
                    }
                }
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::{parse_command, HotkeyCommand, HotkeySpec};

    #[test]
    fn parses_default_and_custom_hotkeys() {
        assert_eq!(HotkeySpec::parse("Ctrl+Alt+Space").unwrap().label, "Ctrl+Alt+Space");
        assert_eq!(HotkeySpec::parse("shift+ctrl+k").unwrap().label, "Ctrl+Shift+K");
        assert_eq!(HotkeySpec::parse("Ctrl+Alt+пробел").unwrap().label, "Ctrl+Alt+Space");
        assert!(HotkeySpec::parse("Ctrl+Alt+F12").is_err());
    }

    #[test]
    fn parses_hotkey_commands() {
        assert_eq!(parse_command("Какая горячая клавиша?"), Some(HotkeyCommand::Show));
        assert_eq!(
            parse_command("Измени горячую клавишу на Ctrl+Alt+K"),
            Some(HotkeyCommand::Set("Ctrl+Alt+K".to_string()))
        );
        assert_eq!(
            parse_command("Поменяй горячую клавишу"),
            Some(HotkeyCommand::PromptForValue)
        );
        assert_eq!(parse_command("гор. клавиши"), Some(HotkeyCommand::Show));
        assert_eq!(parse_command("Какая гор. клавиши?"), Some(HotkeyCommand::Show));
        assert_eq!(
            parse_command("Поменяй гор. клавиши"),
            Some(HotkeyCommand::PromptForValue)
        );
        assert_eq!(
            parse_command("Измени гор. клавиши на Ctrl+Alt+K"),
            Some(HotkeyCommand::Set("Ctrl+Alt+K".to_string()))
        );
    }
}
