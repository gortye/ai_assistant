//! Состояние сетевых подключений и управление адаптерами Windows.
//!
//! Запросы к системе выполняются через PowerShell cmdlets. Изменение состояния
//! адаптера требует административных прав; отключение подтверждается обработчиком
//! команд до передачи действия в этот модуль.

use serde_json::Value;
use std::process::Command;

/// Типизированные сетевые действия, отделённые от текста пользовательской команды.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum NetworkCommand {
    /// Получить состояние физических сетевых подключений.
    GetStatus,
    /// Показать имена и характеристики сетевых адаптеров.
    ListAdapters,
    /// Включить (`enabled = true`) или отключить адаптер с указанным именем.
    SetAdapterEnabled { name: String, enabled: bool },
}

/// Публичный интерфейс распознавания и выполнения сетевых операций.
pub struct NetworkControl;

impl NetworkControl {
    /// Определяет, относится ли фраза к сети, и возвращает сетевое действие.
    /// `Ok(None)` означает, что запрос должен обработать другой модуль.
    pub fn parse_command(input: &str) -> Result<Option<NetworkCommand>, String> {
        let trimmed = input.trim();
        let lower = trimmed
            .to_lowercase()
            .replace('ё', "е")
            .trim_end_matches(|ch| matches!(ch, '?' | '!' | '.'))
            .trim()
            .to_string();
        let search_text = remove_quoted_text(&lower);

        if contains_any(
            &search_text,
            &[
                "покажи сетевые адаптеры",
                "список сетевых адаптеров",
                "список адаптеров",
                "сетевые адаптеры",
                "какие адаптеры",
                "покажи адаптеры",
            ],
        ) {
            return Ok(Some(NetworkCommand::ListAdapters));
        }

        if let Some((enabled, name)) = parse_adapter_change(trimmed, &lower)? {
            return Ok(Some(NetworkCommand::SetAdapterEnabled { name, enabled }));
        }

        if contains_any(
            &search_text,
            &[
                "состояние сети",
                "статус сети",
                "какая сеть",
                "есть интернет",
                "есть ли интернет",
                "работает ли интернет",
                "сеть работает",
                "подключен ли интернет",
                "подключен ли я к интернету",
                "проверь интернет",
                "проверь сеть",
                "информация о сети",
            ],
        ) || matches!(search_text.trim(), "сеть" | "интернет" | "состояние подключения" | "а сеть" | "а интернет")
        {
            return Ok(Some(NetworkCommand::GetStatus));
        }

        Ok(None)
    }

    /// Направляет действие к соответствующей функции PowerShell/Windows.
    pub fn execute(command: NetworkCommand) -> Result<String, String> {
        match command {
            NetworkCommand::GetStatus => get_network_status(),
            NetworkCommand::ListAdapters => list_adapters(),
            NetworkCommand::SetAdapterEnabled { name, enabled } => {
                set_adapter_enabled(&name, enabled)
            }
        }
    }
}

/// Проверяет наличие одной из фраз в тексте команды.
fn contains_any(text: &str, values: &[&str]) -> bool {
    values.iter().any(|value| text.contains(value))
}

/// Разбирает команду включения/отключения и сохраняет указанное имя адаптера.
/// Имя в кавычках извлекается целиком, включая пробелы.
fn parse_adapter_change(
    original: &str,
    lower: &str,
) -> Result<Option<(bool, String)>, String> {
    let patterns = [
        ("отключи сетевой адаптер", false),
        ("отключить сетевой адаптер", false),
        ("выключи сетевой адаптер", false),
        ("выключить сетевой адаптер", false),
        ("отключи адаптер", false),
        ("отключить адаптер", false),
        ("выключи адаптер", false),
        ("выключить адаптер", false),
        ("включи сетевой адаптер", true),
        ("включить сетевой адаптер", true),
        ("включи адаптер", true),
        ("включить адаптер", true),
    ];

    for (prefix, enabled) in patterns {
        if lower.starts_with(prefix) {
            let name = original[prefix.len()..].trim();
            let name = unquote(name);
            if name.is_empty() {
                return Err("Укажи имя адаптера. Сначала можно выполнить команду «список адаптеров».".to_string());
            }
            return Ok(Some((enabled, name)));
        }
    }

    // Удобные короткие команды для стандартного имени Wi-Fi в Windows.
    for prefix in ["отключи wi-fi", "отключить wi-fi", "выключи wi-fi", "выключить wi-fi"] {
        if lower == prefix || lower.starts_with(&format!("{prefix} ")) {
            return Ok(Some((false, "Wi-Fi".to_string())));
        }
    }
    for prefix in ["включи wi-fi", "включить wi-fi"] {
        if lower == prefix || lower.starts_with(&format!("{prefix} ")) {
            return Ok(Some((true, "Wi-Fi".to_string())));
        }
    }

    Ok(None)
}

/// Убирает парные кавычки и завершающую пунктуацию вокруг имени адаптера.
fn unquote(value: &str) -> String {
    let value = value
        .trim()
        .trim_end_matches(|ch| matches!(ch, '.' | '!' | '?'))
        .trim();
    if value.len() >= 2 {
        let first = value.chars().next().unwrap_or(' ');
        let last = value.chars().last().unwrap_or(' ');
        if matches!((first, last), ('"', '"') | ('\'', '\'') | ('«', '»')) {
            return value[first.len_utf8()..value.len() - last.len_utf8()]
                .trim()
                .to_string();
        }
    }
    value.to_string()
}

/// Маскирует имена в кавычках при поиске ключевых слов сетевой команды.
fn remove_quoted_text(text: &str) -> String {
    let mut result = String::with_capacity(text.len());
    let mut closing_quote: Option<char> = None;
    for ch in text.chars() {
        if let Some(end) = closing_quote {
            result.push(' ');
            if ch == end {
                closing_quote = None;
            }
        } else {
            match ch {
                '\'' => { closing_quote = Some('\''); result.push(' '); }
                '"' => { closing_quote = Some('"'); result.push(' '); }
                '«' => { closing_quote = Some('»'); result.push(' '); }
                '„' => { closing_quote = Some('“'); result.push(' '); }
                '“' => { closing_quote = Some('”'); result.push(' '); }
                _ => result.push(ch),
            }
        }
    }
    result
}

/// Собирает состояние физических адаптеров, IP-адреса, шлюзы и DNS.
fn get_network_status() -> Result<String, String> {
    let script = r#"
$ErrorActionPreference = 'Stop'
$utf8 = [System.Text.UTF8Encoding]::new($false)
[Console]::OutputEncoding = $utf8
$OutputEncoding = $utf8
try {
    $items = @(Get-NetAdapter -ErrorAction Stop | Where-Object { $_.HardwareInterface } | ForEach-Object {
        $adapter = $_
        $cfg = Get-NetIPConfiguration -InterfaceIndex $adapter.ifIndex -ErrorAction SilentlyContinue
        [pscustomobject]@{
            Name = [string]$adapter.Name
            Status = [string]$adapter.Status
            LinkSpeed = [string]$adapter.LinkSpeed
            IPv4 = (@($cfg.IPv4Address | ForEach-Object { $_.IPAddress }) -join ', ')
            Gateway = (@($cfg.IPv4DefaultGateway | ForEach-Object { $_.NextHop }) -join ', ')
            Dns = (@($cfg.DnsServer.ServerAddresses) -join ', ')
        }
    })
    if ($items.Count -eq 0) { [Console]::Out.Write('[]') }
    else { ConvertTo-Json -InputObject @($items) -Depth 5 -Compress }
} catch {
    [Console]::Out.WriteLine('ERROR:' + $_.Exception.Message)
    exit 1
}
"#;
    let value = run_powershell_json(script)?;
    format_network_items(&value)
}

/// Возвращает список обнаруженных Windows сетевых адаптеров с их характеристиками.
fn list_adapters() -> Result<String, String> {
    let script = r#"
$ErrorActionPreference = 'Stop'
$utf8 = [System.Text.UTF8Encoding]::new($false)
[Console]::OutputEncoding = $utf8
$OutputEncoding = $utf8
try {
    $items = @(Get-NetAdapter -ErrorAction Stop | Select-Object Name, InterfaceDescription, Status, LinkSpeed, MacAddress)
    if ($items.Count -eq 0) { [Console]::Out.Write('[]') }
    else { ConvertTo-Json -InputObject @($items) -Depth 4 -Compress }
} catch {
    [Console]::Out.WriteLine('ERROR:' + $_.Exception.Message)
    exit 1
}
"#;
    let value = run_powershell_json(script)?;
    if !value.is_array() || value.as_array().is_some_and(|items| items.is_empty()) {
        return Ok("Windows не обнаружила сетевые адаптеры.".to_string());
    }

    let mut lines = vec!["Сетевые адаптеры:".to_string()];
    for item in value.as_array().unwrap() {
        let name = item["Name"].as_str().unwrap_or("Без имени");
        let description = item["InterfaceDescription"].as_str().unwrap_or("");
        let status = translate_status(item["Status"].as_str().unwrap_or("Unknown"));
        let speed = item["LinkSpeed"].as_str().unwrap_or("");
        let mac = item["MacAddress"].as_str().unwrap_or("");
        lines.push(format!("• {name} — {status}; скорость: {}; MAC: {}\n  {description}", empty_as_dash(speed), empty_as_dash(mac),));
    }
    Ok(lines.join("\n"))
}

/// Преобразует JSON-объекты PowerShell в удобный для пользователя текстовый отчёт.
fn format_network_items(value: &Value) -> Result<String, String> {
    let Some(items) = value.as_array() else {
        return Err("Windows вернула неожиданный ответ о сетевых подключениях.".to_string());
    };
    if items.is_empty() {
        return Ok("Физические сетевые адаптеры не найдены.".to_string());
    }

    let mut lines = vec!["Сетевые подключения:".to_string()];
    for item in items {
        let name = item["Name"].as_str().unwrap_or("Без имени");
        let status_raw = item["Status"].as_str().unwrap_or("Unknown");
        let status = translate_status(status_raw);
        let speed = item["LinkSpeed"].as_str().unwrap_or("");
        let ipv4 = item["IPv4"].as_str().unwrap_or("");
        let gateway = item["Gateway"].as_str().unwrap_or("");
        lines.push(format!("• {name}: {status}"));
        if !speed.is_empty() {
            lines.push(format!("  Скорость: {speed}"));
        }
        if !ipv4.is_empty() {
            lines.push(format!("  IPv4: {ipv4}"));
        }
        if !gateway.is_empty() {
            lines.push(format!("  Шлюз: {gateway}"));
        }
    }
    Ok(lines.join("\n"))
}

/// Переводит основные системные статусы адаптера на русский язык.
fn translate_status(status: &str) -> &'static str {
    match status.to_ascii_lowercase().as_str() {
        "up" => "подключён",
        "down" | "disconnected" => "не подключён",
        "disabled" => "выключен",
        "not present" => "не обнаружен",
        "testing" => "проверяется",
        "dormant" => "ожидает активности",
        _ => "состояние неизвестно",
    }
}

/// Заменяет пустые поля отчёта на тире, чтобы форматирование оставалось читаемым.
fn empty_as_dash(value: &str) -> &str {
    if value.is_empty() { "—" } else { value }
}

/// Меняет состояние адаптера с точным совпадением имени.
/// PowerShell дополнительно проверяет права администратора.
fn set_adapter_enabled(name: &str, enabled: bool) -> Result<String, String> {
    let escaped = name.replace('\'', "''");
    let cmdlet = if enabled { "Enable-NetAdapter" } else { "Disable-NetAdapter" };
    let verb = if enabled { "включён" } else { "отключён" };
    let script = format!(
        r#"
$ErrorActionPreference = 'Stop'
$utf8 = [System.Text.UTF8Encoding]::new($false)
[Console]::OutputEncoding = $utf8
$OutputEncoding = $utf8
try {{
    $principal = [Security.Principal.WindowsPrincipal]::new([Security.Principal.WindowsIdentity]::GetCurrent())
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {{
        throw 'Для изменения состояния сетевого адаптера запусти ассистента от имени администратора.'
    }}
    $matches = @(Get-NetAdapter -ErrorAction Stop | Where-Object {{ $_.Name -ieq '{escaped}' }})
    if ($matches.Count -ne 1) {{
        throw 'Не найден сетевой адаптер с таким точным именем. Проверь его название командой «Покажи сетевые адаптеры».'
    }}
    $matches[0] | {cmdlet} -Confirm:$false -ErrorAction Stop | Out-Null
    [Console]::Out.WriteLine('OK')
}} catch {{
    [Console]::Out.WriteLine('ERROR:' + $_.Exception.Message)
    exit 1
}}
"#
    );
    let output = run_powershell(&script)?;
    if output != "OK" {
        return Err(output);
    }
    Ok(format!("Сетевой адаптер «{}» {verb}.", name))
}

/// Выполняет PowerShell-скрипт и преобразует его JSON-ответ в `serde_json::Value`.
fn run_powershell_json(script: &str) -> Result<Value, String> {
    let output = run_powershell(script)?;
    serde_json::from_str(&output)
        .map_err(|error| format!("Не удалось разобрать ответ Windows: {error}. Ответ: {output}"))
}

/// Запускает PowerShell без пользовательского профиля и нормализует ошибки.
fn run_powershell(script: &str) -> Result<String, String> {
    let output = Command::new("powershell.exe")
        .args(["-NoLogo", "-NoProfile", "-NonInteractive", "-Command", script])
        .output()
        .map_err(|error| format!("Не удалось запустить PowerShell: {error}"))?;

    let stdout = String::from_utf8_lossy(&output.stdout).trim().to_string();
    if output.status.success() {
        if let Some(message) = stdout.strip_prefix("ERROR:") {
            return Err(message.trim().to_string());
        }
        Ok(stdout)
    } else {
        let message = stdout
            .strip_prefix("ERROR:")
            .map(str::trim)
            .filter(|message| !message.is_empty())
            .map(str::to_string)
            .unwrap_or_else(|| format!("PowerShell завершился с кодом {:?}.", output.status.code()));
        Err(message)
    }
}

#[cfg(test)]
mod tests {
    use super::{NetworkCommand, NetworkControl};

    #[test]
    fn recognizes_network_status_and_adapter_list() {
        assert_eq!(NetworkControl::parse_command("Какая сеть?"), Ok(Some(NetworkCommand::GetStatus)));
        assert_eq!(NetworkControl::parse_command("Покажи сетевые адаптеры"), Ok(Some(NetworkCommand::ListAdapters)));
    }

    #[test]
    fn recognizes_wifi_toggle() {
        assert_eq!(
            NetworkControl::parse_command("Отключи Wi-Fi"),
            Ok(Some(NetworkCommand::SetAdapterEnabled { name: "Wi-Fi".into(), enabled: false }))
        );
        assert_eq!(
            NetworkControl::parse_command("Включи Wi-Fi"),
            Ok(Some(NetworkCommand::SetAdapterEnabled { name: "Wi-Fi".into(), enabled: true }))
        );
    }

    #[test]
    fn accepts_short_followups_and_punctuation() {
        assert_eq!(NetworkControl::parse_command("А сеть?"), Ok(Some(NetworkCommand::GetStatus)));
        assert_eq!(
            NetworkControl::parse_command("Отключи Wi-Fi?"),
            Ok(Some(NetworkCommand::SetAdapterEnabled { name: "Wi-Fi".into(), enabled: false }))
        );
    }

    #[test]
    fn preserves_quoted_adapter_names() {
        assert_eq!(
            NetworkControl::parse_command("Отключи сетевой адаптер «Ethernet 2»?"),
            Ok(Some(NetworkCommand::SetAdapterEnabled { name: "Ethernet 2".into(), enabled: false }))
        );
    }

    #[test]
    fn ignores_network_words_inside_quoted_file_names() {
        assert_eq!(NetworkControl::parse_command("Создай файл «покажи сетевые адаптеры»"), Ok(None));
    }
}
