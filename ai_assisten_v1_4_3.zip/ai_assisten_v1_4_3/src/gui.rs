//! Native Windows UI with a system-tray icon and a global hotkey.
//! The existing command processor runs as a hidden child process. This keeps
//! the established command behavior intact while the GUI owns the real window
//! and the RegisterHotKey message loop.

//! В этом файле напрямую вызываются Win32 API. Оконные сообщения обрабатываются
//! в главном потоке, а команды выполняются отдельным скрытым процессом, чтобы
//! долгие системные операции не блокировали перерисовку окна.

use crate::hotkey::{self, HotkeyCommand, HotkeySpec};
use std::io::{BufRead, BufReader, Write};
use std::process::{Child, ChildStdin, Command, Stdio};
use std::sync::mpsc::{self, Receiver, Sender, TryRecvError};
use std::thread;
use std::sync::atomic::{AtomicIsize, Ordering};

// Названия главного окна и класса Win32, зарегистрированного при запуске.
const WINDOW_CLASS: &str = "LocalAiAssistantMainWindow";
const WINDOW_TITLE: &str = "Локальный ИИ-ассистент";

// Идентификаторы элементов управления и пунктов меню системного трея.
const ID_OUTPUT: usize = 1001;
const ID_INPUT: usize = 1002;
const ID_SEND: usize = 1003;
const ID_STATUS: usize = 1004;
const ID_TRAY_OPEN: usize = 2001;
const ID_TRAY_EXIT: usize = 2002;

// Идентификаторы глобальной клавиши, значка трея и периодического опроса worker.
const HOTKEY_ID: i32 = 0x4A31;
const TRAY_ICON_ID: u32 = 1;
const WM_TRAY_CALLBACK: u32 = WM_APP + 1;
const TIMER_ID: usize = 1;
const TIMER_INTERVAL_MS: u32 = 100;

// Коды сообщений Win32, которые обрабатывает window_proc.
const WM_CREATE: u32 = 0x0001;
const WM_DESTROY: u32 = 0x0002;
const WM_SIZE: u32 = 0x0005;
const WM_CLOSE: u32 = 0x0010;
const WM_COMMAND: u32 = 0x0111;
const WM_TIMER: u32 = 0x0113;
const WM_NCCREATE: u32 = 0x0081;
const WM_NCDESTROY: u32 = 0x0082;
const WM_HOTKEY: u32 = 0x0312;
const WM_APP: u32 = 0x8000;
const WM_APP_UNINSTALL_EXIT: u32 = WM_APP + 2;
const WM_KEYDOWN: u32 = 0x0100;
const WM_CHAR: u32 = 0x0102;
const VK_RETURN: usize = 0x0D;
const GWLP_WNDPROC: i32 = -4;
const WM_LBUTTONUP: u32 = 0x0202;
const WM_LBUTTONDBLCLK: u32 = 0x0203;
const WM_RBUTTONUP: u32 = 0x0205;
const SIZE_MINIMIZED: usize = 1;

// Команды отображения окна и флаги стилей стандартных Win32-контролов.
const SW_HIDE: i32 = 0;
const SW_SHOW: i32 = 5;
const SW_RESTORE: i32 = 9;

const WS_OVERLAPPEDWINDOW: u32 = 0x00CF_0000;
const WS_CHILD: u32 = 0x4000_0000;
const WS_VISIBLE: u32 = 0x1000_0000;
const WS_BORDER: u32 = 0x0080_0000;
const WS_VSCROLL: u32 = 0x0020_0000;
const WS_TABSTOP: u32 = 0x0001_0000;
const ES_MULTILINE: u32 = 0x0004;
const ES_AUTOVSCROLL: u32 = 0x0040;
const ES_READONLY: u32 = 0x0800;
const ES_AUTOHSCROLL: u32 = 0x0080;
const BS_DEFPUSHBUTTON: u32 = 0x0001;
const WS_EX_CLIENTEDGE: u32 = 0x0000_0200;

const CS_HREDRAW: u32 = 0x0002;
const CS_VREDRAW: u32 = 0x0001;
const COLOR_WINDOW: isize = 5;
const CW_USEDEFAULT: i32 = 0x8000_0000u32 as i32;
const GWLP_USERDATA: i32 = -21;

const EM_SETSEL: u32 = 0x00B1;
const EM_SETLIMITTEXT: u32 = 0x00C5;

const MF_STRING: u32 = 0x0000;
const MF_SEPARATOR: u32 = 0x0800;
const TPM_RIGHTBUTTON: u32 = 0x0002;
const TPM_BOTTOMALIGN: u32 = 0x0020;

const NIM_ADD: u32 = 0x0000;
const NIM_DELETE: u32 = 0x0002;
const NIF_MESSAGE: u32 = 0x0001;
const NIF_ICON: u32 = 0x0002;
const NIF_TIP: u32 = 0x0004;
const MOD_NOREPEAT: u32 = 0x4000;
const CREATE_NO_WINDOW: u32 = 0x0800_0000;

// Структуры ниже повторяют ABI Win32. Их порядок и типы полей должны
// соответствовать C-структурам Windows, так как они передаются через FFI.
#[repr(C)]
struct Point {
    x: i32,
    y: i32,
}

#[repr(C)]
struct Rect {
    left: i32,
    top: i32,
    right: i32,
    bottom: i32,
}

#[repr(C)]
struct Msg {
    // Дескрипторы окна и его элементов управления.
    hwnd: isize,
    message: u32,
    _padding: u32,
    w_param: usize,
    l_param: isize,
    time: u32,
    point: Point,
    l_private: u32,
}

#[repr(C)]
struct CreateStructW {
    create_params: *mut std::ffi::c_void,
    instance: isize,
    menu: isize,
    parent: isize,
    cy: i32,
    cx: i32,
    y: i32,
    x: i32,
    style: i32,
    name: *const u16,
    class: *const u16,
    ex_style: u32,
}

type WindowProc = unsafe extern "system" fn(isize, u32, usize, isize) -> isize;

#[repr(C)]
struct WndClassW {
    style: u32,
    wnd_proc: Option<WindowProc>,
    cb_cls_extra: i32,
    cb_wnd_extra: i32,
    instance: isize,
    icon: isize,
    cursor: isize,
    background: isize,
    menu_name: *const u16,
    class_name: *const u16,
}

#[repr(C)]
struct Guid {
    data1: u32,
    data2: u16,
    data3: u16,
    data4: [u8; 8],
}

#[repr(C)]
union NotifyTimeoutVersion {
    timeout: u32,
    version: u32,
}

#[repr(C)]
struct NotifyIconDataW {
    cb_size: u32,
    hwnd: isize,
    uid: u32,
    flags: u32,
    callback_message: u32,
    icon: isize,
    tip: [u16; 128],
    state: u32,
    state_mask: u32,
    info: [u16; 256],
    timeout_or_version: NotifyTimeoutVersion,
    info_title: [u16; 64],
    info_flags: u32,
    guid_item: Guid,
    balloon_icon: isize,
}

/// Состояние главного окна: HWND контролов, дочерний процесс, каналы связи,
/// активная горячая клавиша и флаги жизненного цикла приложения.
struct AppState {
    hwnd: isize,
    output: isize,
    input: isize,
    send_button: isize,
    status: isize,
    // Дочерний процесс, который распознаёт и исполняет команды.
    worker: Option<Child>,
    worker_stdin: Option<ChildStdin>,
    // Канал строк, прочитанных из stdout/stderr рабочего процесса.
    worker_output: Receiver<String>,
    worker_exited: bool,
    // Текущая комбинация и состояния диалогов/интеграции с треем.
    active_hotkey: HotkeySpec,
    hotkey_registered: bool,
    awaiting_hotkey_value: bool,
    awaiting_uninstall_confirmation: bool,
    tray_added: bool,
    pending_startup_warning: Option<String>,
}

// Гарантирует освобождение хоткея, значка трея и worker при уничтожении состояния.
impl Drop for AppState {
    fn drop(&mut self) {
        self.cleanup();
    }
}

impl AppState {
    /// Создаёт состояние GUI и сразу запускает внутренний процесс-обработчик.
    fn new() -> Result<Self, String> {
        let (worker, worker_stdin, worker_output) = spawn_worker()?;
        let (active_hotkey, config_warning) = hotkey::load_or_default();
        let mut state = Self {
            hwnd: 0,
            output: 0,
            input: 0,
            send_button: 0,
            status: 0,
            worker: Some(worker),
            worker_stdin: Some(worker_stdin),
            worker_output,
            worker_exited: false,
            active_hotkey,
            hotkey_registered: false,
            awaiting_hotkey_value: false,
            awaiting_uninstall_confirmation: false,
            tray_added: false,
            pending_startup_warning: None,
        };
        if let Some(warning) = config_warning {
            state.pending_startup_warning = Some(warning);
        }
        Ok(state)
    }

    // Stored separately so the warning can be displayed after child controls exist.
    /// Однократно забирает предупреждение о некорректном файле настроек.
    fn startup_warning(&mut self) -> Option<String> {
        self.pending_startup_warning.take()
    }

    /// Добавляет строку в историю окна и прокручивает поле вывода вниз.
    /// Старые строки ограничиваются по объёму, чтобы история не росла бесконечно.
    fn append(&self, message: &str) {
        if self.output == 0 || message.is_empty() {
            return;
        }
        let mut normalized = message.replace("\r\n", "\n").replace('\n', "\r\n");
        normalized.push_str("\r\n");
        unsafe {
            // Read-only edit controls reliably accept SetWindowTextW, while
            // EM_REPLACESEL can be ignored on some read-only control styles.
            let old_len = GetWindowTextLengthW(self.output).max(0) as usize;
            let mut old_buffer = vec![0u16; old_len + 1];
            let read = GetWindowTextW(self.output, old_buffer.as_mut_ptr(), old_buffer.len() as i32).max(0) as usize;
            let old_text = String::from_utf16_lossy(&old_buffer[..read]);
            let mut combined = format!("{old_text}{normalized}");
            if combined.chars().count() > 450_000 {
                combined = combined.chars().skip(combined.chars().count() - 400_000).collect();
            }
            let wide = to_wide(&combined);
            SetWindowTextW(self.output, wide.as_ptr());
            SendMessageW(self.output, EM_SETSEL, usize::MAX, -1);
            SendMessageW(self.output, 0x00B7, 0, 0); // EM_SCROLLCARET
        }
    }

    /// Обновляет нижнюю строку состояния окна.
    fn set_status(&self, message: &str) {
        if self.status != 0 {
            let wide = to_wide(message);
            unsafe { SetWindowTextW(self.status, wide.as_ptr()) };
        }
    }

    /// Забирает накопившийся вывод worker и проверяет, не завершился ли процесс.
    fn poll_worker(&mut self) {
        loop {
            match self.worker_output.try_recv() {
                Ok(line) => {
                    let text = line.strip_prefix("Вы> ").unwrap_or(&line);
                    if !text.trim().is_empty() {
                        self.append(text);
                    }
                }
                Err(TryRecvError::Empty) => break,
                Err(TryRecvError::Disconnected) => break,
            }
        }

        if !self.worker_exited {
            if let Some(worker) = self.worker.as_mut() {
                match worker.try_wait() {
                    Ok(Some(status)) => {
                        self.worker_exited = true;
                        self.worker_stdin.take();
                        self.append(&format!("Обработчик команд завершился: {status}. Перезапусти приложение, чтобы продолжить."));
                        self.set_status("Обработчик команд остановлен");
                    }
                    Ok(None) => {}
                    Err(error) => self.append(&format!("Не удалось проверить состояние обработчика: {error}")),
                }
            }
        }
    }

    /// Передаёт пользовательскую строку дочернему обработчику через stdin.
    fn send_to_worker(&mut self, command: &str) {
        if self.worker_exited {
            self.append("Обработчик команд уже завершился. Перезапусти приложение.");
            return;
        }
        let Some(stdin) = self.worker_stdin.as_mut() else {
            self.append("Нет канала связи с обработчиком команд.");
            return;
        };
        if let Err(error) = writeln!(stdin, "{command}").and_then(|_| stdin.flush()) {
            self.append(&format!("Не удалось передать команду: {error}"));
            self.set_status("Ошибка связи с обработчиком");
        }
    }

    /// Освобождает зарегистрированный хоткей и значок трея, затем завершает worker.
    fn cleanup(&mut self) {
        if self.hotkey_registered && self.hwnd != 0 {
            unsafe { UnregisterHotKey(self.hwnd, HOTKEY_ID) };
            self.hotkey_registered = false;
        }
        if self.tray_added && self.hwnd != 0 {
            let data = unsafe { tray_data(self.hwnd) };
            unsafe { Shell_NotifyIconW(NIM_DELETE, &data) };
            self.tray_added = false;
        }
        if let Some(mut worker) = self.worker.take() {
            let _ = worker.kill();
            let _ = worker.wait();
        }
        self.worker_stdin.take();
    }

}

/// Повторно запускает текущий EXE с `--worker` и открывает stdin/stdout/stderr.
fn spawn_worker() -> Result<(Child, ChildStdin, Receiver<String>), String> {
    let executable = std::env::current_exe()
        .map_err(|error| format!("Не удалось определить путь к EXE: {error}"))?;
    let mut command = Command::new(executable);
    command
        .arg("--worker")
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped());

    #[cfg(windows)]
    {
        use std::os::windows::process::CommandExt;
        command.creation_flags(CREATE_NO_WINDOW);
    }

    let mut child = command
        .spawn()
        .map_err(|error| format!("Не удалось запустить внутренний обработчик команд: {error}"))?;
    let stdin = child
        .stdin
        .take()
        .ok_or_else(|| "Не удалось открыть канал ввода обработчика.".to_string())?;
    let stdout = child
        .stdout
        .take()
        .ok_or_else(|| "Не удалось открыть канал вывода обработчика.".to_string())?;
    let stderr = child.stderr.take();

    let (sender, receiver) = mpsc::channel();
    spawn_pipe_reader(BufReader::new(stdout), sender.clone(), false);
    if let Some(stderr) = stderr {
        spawn_pipe_reader(BufReader::new(stderr), sender, true);
    }

    Ok((child, stdin, receiver))
}

/// Читает поток построчно в отдельном потоке, чтобы не блокировать главный GUI.
fn spawn_pipe_reader<R: BufRead + Send + 'static>(reader: R, sender: Sender<String>, is_error: bool) {
    thread::spawn(move || {
        for line in reader.lines() {
            match line {
                Ok(line) => {
                    let message = if is_error {
                        format!("Ошибка обработчика: {line}")
                    } else {
                        line
                    };
                    if sender.send(message).is_err() {
                        break;
                    }
                }
                Err(error) => {
                    let _ = sender.send(format!("Ошибка чтения вывода обработчика: {error}"));
                    break;
                }
            }
        }
    });
}

/// Регистрирует класс окна, создаёт главное окно и запускает цикл сообщений Win32.
pub fn run() -> Result<(), String> {
    let mut state = Box::new(AppState::new()?);
    let state_ptr = (&mut *state) as *mut AppState;

    unsafe {
        let instance = GetModuleHandleW(std::ptr::null());
        if instance == 0 {
            return Err(format!("GetModuleHandleW завершился ошибкой {}.", GetLastError()));
        }

        let class_name = to_wide(WINDOW_CLASS);
        let icon = LoadIconW(0, 32512usize as *const u16);
        let cursor = LoadCursorW(0, 32512usize as *const u16);
        let window_class = WndClassW {
            style: CS_HREDRAW | CS_VREDRAW,
            wnd_proc: Some(window_proc),
            cb_cls_extra: 0,
            cb_wnd_extra: 0,
            instance,
            icon,
            cursor,
            background: (COLOR_WINDOW + 1) as isize,
            menu_name: std::ptr::null(),
            class_name: class_name.as_ptr(),
        };

        if RegisterClassW(&window_class) == 0 {
            return Err(format!("Не удалось зарегистрировать класс окна. Код Windows: {}.", GetLastError()));
        }

        let title = to_wide(WINDOW_TITLE);
        let hwnd = CreateWindowExW(
            0,
            class_name.as_ptr(),
            title.as_ptr(),
            WS_OVERLAPPEDWINDOW | WS_VISIBLE,
            CW_USEDEFAULT,
            CW_USEDEFAULT,
            860,
            700,
            0,
            0,
            instance,
            state_ptr.cast(),
        );
        if hwnd == 0 {
            return Err(format!("Не удалось создать окно ассистента. Код Windows: {}.", GetLastError()));
        }

        state.hwnd = hwnd;
        ShowWindow(hwnd, SW_SHOW);
        UpdateWindow(hwnd);
        if state.input != 0 {
            SetFocus(state.input);
        }

        let mut message = Msg {
            hwnd: 0,
            message: 0,
            _padding: 0,
            w_param: 0,
            l_param: 0,
            time: 0,
            point: Point { x: 0, y: 0 },
            l_private: 0,
        };

        loop {
            let result = GetMessageW(&mut message, 0, 0, 0);
            if result == 0 {
                break;
            }
            if result == -1 {
                return Err(format!("Ошибка цикла сообщений Windows: {}.", GetLastError()));
            }
            TranslateMessage(&message);
            DispatchMessageW(&message);
        }
    }

    Ok(())
}

/// Показывает системное окно ошибки, если графический интерфейс не удалось запустить.
pub fn show_fatal_error(message: &str) {
    let text = to_wide(message);
    let title = to_wide("Локальный ИИ-ассистент — ошибка запуска");
    unsafe { MessageBoxW(0, text.as_ptr(), title.as_ptr(), 0x0000_0010) };
}

/// Главный обработчик Win32-сообщений: создание контролов, ввод, таймер worker,
/// сворачивание в трей, глобальный хоткей и штатное завершение приложения.
unsafe extern "system" fn window_proc(hwnd: isize, message: u32, w_param: usize, l_param: isize) -> isize {
    if message == WM_NCCREATE {
        let create = &*(l_param as *const CreateStructW);
        SetWindowLongPtrW(hwnd, GWLP_USERDATA, create.create_params as isize);
        return 1;
    }

    let state_ptr = GetWindowLongPtrW(hwnd, GWLP_USERDATA) as *mut AppState;

    match message {
        WM_CREATE => {
            if !state_ptr.is_null() {
                let state = &mut *state_ptr;
                state.hwnd = hwnd;
                create_controls(hwnd, state);
                state.tray_added = add_tray_icon(hwnd);
                if !state.tray_added {
                    state.append("Не удалось создать значок в системном трее. Закрытие окна завершит программу, а не скроет её.");
                }
                match register_hotkey(hwnd, &state.active_hotkey) {
                    Ok(()) => {
                        state.hotkey_registered = true;
                        if state.tray_added {
                            state.set_status(&format!("Работает в фоне · горячая клавиша: {} · окно можно скрыть в трей", state.active_hotkey.label));
                        } else {
                            state.set_status(&format!("Горячая клавиша: {} · значок трея недоступен", state.active_hotkey.label));
                        }
                    }
                    Err(error) => {
                        state.hotkey_registered = false;
                        state.set_status("Горячая клавиша не зарегистрирована");
                        state.append(&format!("Не удалось зарегистрировать {}: {error}", state.active_hotkey.label));
                    }
                }
                if let Some(warning) = state.startup_warning() {
                    state.append(&format!("Предупреждение настроек: {warning}"));
                }
                if state.tray_added {
                    state.append("Ассистент запущен. Закрытие окна или сворачивание скрывает его в системный трей. Для полного выхода используй меню значка возле часов.");
                } else {
                    state.append("Ассистент запущен. Значок трея недоступен, поэтому закрытие окна полностью завершит программу.");
                }
                SetTimer(hwnd, TIMER_ID, TIMER_INTERVAL_MS, None);
            }
            0
        }
        WM_SIZE => {
            if w_param == SIZE_MINIMIZED {
                if !state_ptr.is_null() && (*state_ptr).tray_added {
                    ShowWindow(hwnd, SW_HIDE);
                }
            } else if !state_ptr.is_null() {
                resize_controls(hwnd, &*state_ptr);
            }
            0
        }
        WM_COMMAND => {
            let command_id = w_param & 0xFFFF;
            if command_id == ID_SEND {
                if !state_ptr.is_null() {
                    send_input(&mut *state_ptr);
                }
                0
            } else if command_id == ID_TRAY_OPEN {
                show_main_window(hwnd, state_ptr);
                0
            } else if command_id == ID_TRAY_EXIT {
                DestroyWindow(hwnd);
                0
            } else {
                DefWindowProcW(hwnd, message, w_param, l_param)
            }
        }
        WM_HOTKEY => {
            if w_param as i32 == HOTKEY_ID {
                show_main_window(hwnd, state_ptr);
            }
            0
        }
        WM_APP_UNINSTALL_EXIT => {
            // Закрытие отложено до выхода из send_input, чтобы не создавать
            // повторный mutable-доступ к AppState во время обработки команды.
            DestroyWindow(hwnd);
            0
        }
        WM_TRAY_CALLBACK => {
            let event = l_param as u32;
            if event == WM_LBUTTONUP || event == WM_LBUTTONDBLCLK {
                show_main_window(hwnd, state_ptr);
            } else if event == WM_RBUTTONUP {
                show_tray_menu(hwnd);
            }
            0
        }
        WM_TIMER if w_param == TIMER_ID => {
            if !state_ptr.is_null() {
                (&mut *state_ptr).poll_worker();
            }
            0
        }
        WM_CLOSE => {
            if !state_ptr.is_null() && (*state_ptr).tray_added {
                ShowWindow(hwnd, SW_HIDE);
                (&*state_ptr).set_status("Ассистент работает в фоне · открой его через значок в трее или горячую клавишу");
            } else {
                // Если Windows не смогла добавить значок в трей, не оставляем
                // пользователя с невидимым процессом.
                DestroyWindow(hwnd);
            }
            0
        }
        WM_DESTROY => {
            if !state_ptr.is_null() {
                (&mut *state_ptr).cleanup();
            }
            KillTimer(hwnd, TIMER_ID);
            PostQuitMessage(0);
            0
        }
        WM_NCDESTROY => {
            SetWindowLongPtrW(hwnd, GWLP_USERDATA, 0);
            DefWindowProcW(hwnd, message, w_param, l_param)
        }
        _ => DefWindowProcW(hwnd, message, w_param, l_param),
    }
}

/// Создаёт подпись, историю сообщений, поле ввода, кнопку и строку состояния.
unsafe fn create_controls(hwnd: isize, state: &mut AppState) {
    let instance = GetModuleHandleW(std::ptr::null());
    let label = to_wide("Напиши команду обычным языком и нажми Enter. Например: «Установи громкость 30%» или «Создай папку Учёба».");
    let static_class = to_wide("STATIC");
    let output_class = to_wide("EDIT");
    let input_class = to_wide("EDIT");
    let button_class = to_wide("BUTTON");
    let empty = to_wide("");
    let send_text = to_wide("Отправить");

    CreateWindowExW(0, static_class.as_ptr(), label.as_ptr(), WS_CHILD | WS_VISIBLE, 16, 12, 810, 24, hwnd, 0, instance, std::ptr::null_mut());
    state.output = CreateWindowExW(
        WS_EX_CLIENTEDGE,
        output_class.as_ptr(),
        empty.as_ptr(),
        WS_CHILD | WS_VISIBLE | WS_BORDER | WS_VSCROLL | WS_TABSTOP | ES_MULTILINE | ES_AUTOVSCROLL | ES_READONLY,
        16, 42, 810, 530, hwnd, ID_OUTPUT as isize, instance, std::ptr::null_mut(),
    );
    state.input = CreateWindowExW(
        WS_EX_CLIENTEDGE,
        input_class.as_ptr(),
        empty.as_ptr(),
        WS_CHILD | WS_VISIBLE | WS_BORDER | WS_TABSTOP | ES_AUTOHSCROLL,
        16, 584, 690, 32, hwnd, ID_INPUT as isize, instance, std::ptr::null_mut(),
    );
    if state.input != 0 {
        // Однострочное поле EDIT не отправляет WM_KEYDOWN родителю.
        // Подменяем его оконную процедуру, чтобы Enter вызывал отправку.
        let previous = SetWindowLongPtrW(state.input, GWLP_WNDPROC, input_window_proc as usize as isize);
        if previous != 0 {
            INPUT_ORIGINAL_PROC.store(previous, Ordering::SeqCst);
        }
    }
    state.send_button = CreateWindowExW(
        0,
        button_class.as_ptr(),
        send_text.as_ptr(),
        WS_CHILD | WS_VISIBLE | WS_TABSTOP | BS_DEFPUSHBUTTON,
        716, 584, 110, 32, hwnd, ID_SEND as isize, instance, std::ptr::null_mut(),
    );
    state.status = CreateWindowExW(
        0,
        static_class.as_ptr(),
        empty.as_ptr(),
        WS_CHILD | WS_VISIBLE,
        16, 628, 810, 24, hwnd, ID_STATUS as isize, instance, std::ptr::null_mut(),
    );

    if state.output != 0 {
        SendMessageW(state.output, EM_SETLIMITTEXT, 500_000, 0);
    }
}

// Сохраняем исходную оконную процедуру EDIT, чтобы передавать ей сообщения,
// которые не обрабатываются нашим перехватчиком Enter.
static INPUT_ORIGINAL_PROC: AtomicIsize = AtomicIsize::new(0);

/// Перехватчик однострочного поля ввода: Enter отправляет WM_COMMAND кнопки «Отправить».
/// Остальные сообщения передаются стандартной оконной процедуре EDIT.
unsafe extern "system" fn input_window_proc(hwnd: isize, message: u32, w_param: usize, l_param: isize) -> isize {
    if message == WM_KEYDOWN && w_param == VK_RETURN {
        let parent = GetParent(hwnd);
        if parent != 0 {
            PostMessageW(parent, WM_COMMAND, ID_SEND, 0);
        }
        return 0;
    }
    if message == WM_CHAR && w_param == VK_RETURN {
        return 0;
    }

    let previous = INPUT_ORIGINAL_PROC.load(Ordering::SeqCst);
    if previous != 0 {
        CallWindowProcW(previous, hwnd, message, w_param, l_param)
    } else {
        DefWindowProcW(hwnd, message, w_param, l_param)
    }
}

/// Пересчитывает размеры дочерних контролов при изменении размера окна.
unsafe fn resize_controls(hwnd: isize, state: &AppState) {
    let mut rect = Rect { left: 0, top: 0, right: 860, bottom: 700 };
    if GetClientRect(hwnd, &mut rect) == 0 {
        return;
    }
    let width = rect.right - rect.left;
    let height = rect.bottom - rect.top;
    let output_height = (height - 126).max(160);
    let input_y = output_height + 56;
    MoveWindow(state.output, 16, 42, (width - 32).max(300), output_height, 1);
    MoveWindow(state.input, 16, input_y, (width - 156).max(120), 32, 1);
    MoveWindow(state.send_button, (width - 126).max(150), input_y, 110, 32, 1);
    MoveWindow(state.status, 16, input_y + 42, (width - 32).max(200), 24, 1);
}

/// Восстанавливает окно поверх остальных окон и возвращает фокус в поле ввода.
unsafe fn show_main_window(hwnd: isize, state_ptr: *mut AppState) {
    ShowWindow(hwnd, SW_RESTORE);
    SetForegroundWindow(hwnd);
    if !state_ptr.is_null() {
        let state = &*state_ptr;
        if state.input != 0 {
            SetFocus(state.input);
        }
    }
}

/// Читает введённый текст, обрабатывает локальные команды GUI (хоткей/удаление)
/// и передаёт остальные команды дочернему процессу.
unsafe fn send_input(state: &mut AppState) {
    if state.input == 0 {
        return;
    }
    let length = GetWindowTextLengthW(state.input).max(0) as usize;
    if length == 0 {
        return;
    }
    let mut buffer = vec![0u16; length + 1];
    let read = GetWindowTextW(state.input, buffer.as_mut_ptr(), buffer.len() as i32).max(0) as usize;
    let raw_input = String::from_utf16_lossy(&buffer[..read]).trim().to_string();
    if raw_input.is_empty() {
        return;
    }
    let corrected = crate::maybe_correct_russian_keyboard_layout(&raw_input);
    let input = corrected.as_deref().unwrap_or(&raw_input).to_string();

    let empty = to_wide("");
    SetWindowTextW(state.input, empty.as_ptr());
    state.append(&format!("Вы: {raw_input}"));
    if let Some(corrected) = corrected.as_deref() {
        state.append(&format!("(Распознал русскую команду в английской раскладке: {corrected})"));
    }

    if state.awaiting_uninstall_confirmation {
        let confirmation = input
            .to_lowercase()
            .replace('ё', "е")
            .trim()
            .trim_end_matches(|ch| matches!(ch, '?' | '!' | '.'))
            .trim()
            .to_string();
        if matches!(confirmation.as_str(), "отмена" | "cancel") {
            state.awaiting_uninstall_confirmation = false;
            state.append("Самоуничтожение отменено. Приложение продолжает работать.");
            return;
        }
        if crate::self_uninstall::is_confirmation(&input) {
            state.awaiting_uninstall_confirmation = false;
            match crate::self_uninstall::spawn_uninstaller() {
                Ok(message) => {
                    state.append(&format!("{message} Помощник удаления завершит очистку после закрытия приложения."));
                    PostMessageW(state.hwnd, WM_APP_UNINSTALL_EXIT, 0, 0);
                }
                Err(error) => state.append(&format!("Не удалось подготовить удаление: {error}")),
            }
            return;
        }
        state.append("Подтверждение не совпало. Для удаления напиши «УДАЛИТЬ АССИСТЕНТА», либо «отмена».");
        return;
    }

    if crate::self_uninstall::is_request(&input) {
        state.awaiting_hotkey_value = false;
        state.awaiting_uninstall_confirmation = true;
        state.append("Запрошено самоуничтожение приложения. Будет удалён только текущий EXE; если он был создан build_windows.bat и находится в dist с маркером установки, будет удалена только эта папка dist. Также удалится файл настройки горячей клавиши. Исходный проект, документы пользователя, другие папки и системные компоненты не затрагиваются.");
        state.append("Для подтверждения напиши ровно: УДАЛИТЬ АССИСТЕНТА. Для отказа напиши: отмена.");
        return;
    }

    if input.eq_ignore_ascii_case("выход") || input.eq_ignore_ascii_case("exit") {
        state.append("Окно не завершает работу ассистента. Для полного выхода нажми правой кнопкой по значку в трее и выбери «Завершить».");
        return;
    }

    if state.awaiting_hotkey_value {
        if matches!(input.to_lowercase().as_str(), "отмена" | "cancel") {
            state.awaiting_hotkey_value = false;
            state.append("Изменение горячей клавиши отменено.");
            return;
        }
        match HotkeySpec::parse(&input) {
            Ok(spec) => {
                state.awaiting_hotkey_value = false;
                match apply_hotkey(state, spec) {
                    Ok(message) => state.append(&message),
                    Err(error) => state.append(&format!("Не удалось изменить горячую клавишу: {error}")),
                }
            }
            Err(error) => {
                state.append(&error);
                state.append("Введи сочетание, например Ctrl+Alt+K, или напиши «отмена».");
            }
        }
        return;
    }

    if let Some(command) = hotkey::parse_command(&input) {
        match command {
            HotkeyCommand::Show => state.append(&format!("Текущая горячая клавиша: {}.", state.active_hotkey.label)),
            HotkeyCommand::PromptForValue => {
                state.awaiting_hotkey_value = true;
                state.append("Введи новое сочетание, например Ctrl+Alt+K. Для отмены напиши «отмена».");
            }
            HotkeyCommand::Set(raw) => match HotkeySpec::parse(&raw) {
                Ok(spec) => match apply_hotkey(state, spec) {
                    Ok(message) => state.append(&message),
                    Err(error) => state.append(&format!("Не удалось изменить горячую клавишу: {error}")),
                },
                Err(error) => state.append(&error),
            },
        }
        return;
    }

    state.send_to_worker(&input);
}

/// Меняет глобальное сочетание, пытается восстановить прежнее при ошибке
/// регистрации/сохранения и обновляет строку состояния.
fn apply_hotkey(state: &mut AppState, next: HotkeySpec) -> Result<String, String> {
    let previous = state.active_hotkey.clone();
    unsafe {
        if state.hotkey_registered {
            UnregisterHotKey(state.hwnd, HOTKEY_ID);
            state.hotkey_registered = false;
        }
        if register_hotkey(state.hwnd, &next).is_err() {
            let restore = register_hotkey(state.hwnd, &previous);
            state.hotkey_registered = restore.is_ok();
            return Err(format!(
                "сочетание {} не удалось зарегистрировать (возможно, оно занято другой программой). {}",
                next.label,
                if restore.is_ok() { format!("Вернул прежнее сочетание {}.", previous.label) } else { "Прежнее сочетание тоже не удалось восстановить.".to_string() }
            ));
        }
        state.hotkey_registered = true;

        if let Err(error) = hotkey::save(&next) {
            UnregisterHotKey(state.hwnd, HOTKEY_ID);
            let restore = register_hotkey(state.hwnd, &previous);
            state.hotkey_registered = restore.is_ok();
            return Err(format!("не удалось сохранить настройку: {error}. {}", if restore.is_ok() { format!("Вернул {}.", previous.label) } else { "Не удалось восстановить старое сочетание.".to_string() }));
        }
    }
    state.active_hotkey = next;
    state.set_status(&format!("Горячая клавиша: {} · окно можно вернуть из трея", state.active_hotkey.label));
    Ok(format!("Горячая клавиша изменена на {} и сохранена. Теперь это сочетание открывает окно ассистента.", state.active_hotkey.label))
}

/// Регистрирует сочетание за окном через RegisterHotKey.
unsafe fn register_hotkey(hwnd: isize, spec: &HotkeySpec) -> Result<(), String> {
    let modifiers = spec.modifiers | MOD_NOREPEAT;
    if RegisterHotKey(hwnd, HOTKEY_ID, modifiers, spec.virtual_key) == 0 {
        Err(format!("Windows вернула код ошибки {}.", GetLastError()))
    } else {
        Ok(())
    }
}

/// Добавляет значок приложения в системную область уведомлений Windows.
unsafe fn add_tray_icon(hwnd: isize) -> bool {
    let data = tray_data(hwnd);
    Shell_NotifyIconW(NIM_ADD, &data) != 0
}

/// Формирует структуру NOTIFYICONDATAW для значка и callback-сообщений трея.
unsafe fn tray_data(hwnd: isize) -> NotifyIconDataW {
    let icon = LoadIconW(0, 32512usize as *const u16);
    let mut data = NotifyIconDataW {
        cb_size: std::mem::size_of::<NotifyIconDataW>() as u32,
        hwnd,
        uid: TRAY_ICON_ID,
        flags: NIF_MESSAGE | NIF_ICON | NIF_TIP,
        callback_message: WM_TRAY_CALLBACK,
        icon,
        tip: [0; 128],
        state: 0,
        state_mask: 0,
        info: [0; 256],
        timeout_or_version: NotifyTimeoutVersion { version: 0 },
        info_title: [0; 64],
        info_flags: 0,
        guid_item: Guid { data1: 0, data2: 0, data3: 0, data4: [0; 8] },
        balloon_icon: 0,
    };
    let tip = to_wide("Локальный ИИ-ассистент");
    let count = tip.len().min(data.tip.len());
    data.tip[..count].copy_from_slice(&tip[..count]);
    data
}

/// Показывает контекстное меню трея: открыть окно или полностью завершить работу.
unsafe fn show_tray_menu(hwnd: isize) {
    let menu = CreatePopupMenu();
    if menu == 0 {
        return;
    }
    let open = to_wide("Открыть ассистента");
    let exit = to_wide("Завершить работу");
    AppendMenuW(menu, MF_STRING, ID_TRAY_OPEN, open.as_ptr());
    AppendMenuW(menu, MF_SEPARATOR, 0, std::ptr::null());
    AppendMenuW(menu, MF_STRING, ID_TRAY_EXIT, exit.as_ptr());

    let mut point = Point { x: 0, y: 0 };
    if GetCursorPos(&mut point) != 0 {
        SetForegroundWindow(hwnd);
        TrackPopupMenu(menu, TPM_RIGHTBUTTON | TPM_BOTTOMALIGN, point.x, point.y, 0, hwnd, std::ptr::null());
    }
    DestroyMenu(menu);
}

/// Преобразует UTF-8 строку Rust в завершаемую нулём UTF-16 строку для Win32 API.
fn to_wide(value: &str) -> Vec<u16> {
    value.encode_utf16().chain(std::iter::once(0)).collect()
}

#[link(name = "kernel32")]
extern "system" {
    fn GetModuleHandleW(module_name: *const u16) -> isize;
    fn GetLastError() -> u32;
}

#[link(name = "user32")]
extern "system" {
    fn RegisterClassW(class: *const WndClassW) -> u16;
    fn CreateWindowExW(ex_style: u32, class_name: *const u16, window_name: *const u16, style: u32, x: i32, y: i32, width: i32, height: i32, parent: isize, menu: isize, instance: isize, parameter: *mut std::ffi::c_void) -> isize;
    fn DefWindowProcW(hwnd: isize, message: u32, w_param: usize, l_param: isize) -> isize;
    fn SetWindowLongPtrW(hwnd: isize, index: i32, value: isize) -> isize;
    fn GetWindowLongPtrW(hwnd: isize, index: i32) -> isize;
    fn CallWindowProcW(previous: isize, hwnd: isize, message: u32, w_param: usize, l_param: isize) -> isize;
    fn GetParent(hwnd: isize) -> isize;
    fn PostMessageW(hwnd: isize, message: u32, w_param: usize, l_param: isize) -> i32;
    fn ShowWindow(hwnd: isize, command: i32) -> i32;
    fn UpdateWindow(hwnd: isize) -> i32;
    fn SetForegroundWindow(hwnd: isize) -> i32;
    fn SetFocus(hwnd: isize) -> isize;
    fn DestroyWindow(hwnd: isize) -> i32;
    fn GetMessageW(message: *mut Msg, hwnd: isize, min: u32, max: u32) -> i32;
    fn TranslateMessage(message: *const Msg) -> i32;
    fn DispatchMessageW(message: *const Msg) -> isize;
    fn PostQuitMessage(exit_code: i32);
    fn GetWindowTextLengthW(hwnd: isize) -> i32;
    fn GetWindowTextW(hwnd: isize, text: *mut u16, max_count: i32) -> i32;
    fn SetWindowTextW(hwnd: isize, text: *const u16) -> i32;
    fn SendMessageW(hwnd: isize, message: u32, w_param: usize, l_param: isize) -> isize;
    fn MoveWindow(hwnd: isize, x: i32, y: i32, width: i32, height: i32, repaint: i32) -> i32;
    fn GetClientRect(hwnd: isize, rect: *mut Rect) -> i32;
    fn SetTimer(hwnd: isize, id: usize, interval: u32, callback: Option<unsafe extern "system" fn(isize, u32, usize, u32)>) -> usize;
    fn KillTimer(hwnd: isize, id: usize) -> i32;
    fn LoadIconW(instance: isize, icon_name: *const u16) -> isize;
    fn LoadCursorW(instance: isize, cursor_name: *const u16) -> isize;
    fn MessageBoxW(hwnd: isize, text: *const u16, caption: *const u16, kind: u32) -> i32;
    fn RegisterHotKey(hwnd: isize, id: i32, modifiers: u32, virtual_key: u32) -> i32;
    fn UnregisterHotKey(hwnd: isize, id: i32) -> i32;
    fn CreatePopupMenu() -> isize;
    fn AppendMenuW(menu: isize, flags: u32, item_id: usize, item_text: *const u16) -> i32;
    fn TrackPopupMenu(menu: isize, flags: u32, x: i32, y: i32, reserved: i32, hwnd: isize, rect: *const Rect) -> i32;
    fn DestroyMenu(menu: isize) -> i32;
    fn GetCursorPos(point: *mut Point) -> i32;
}

#[link(name = "shell32")]
extern "system" {
    fn Shell_NotifyIconW(message: u32, data: *const NotifyIconDataW) -> i32;
}
