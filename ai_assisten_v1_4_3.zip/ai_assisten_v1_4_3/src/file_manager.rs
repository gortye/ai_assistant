//! Файловые операции, вызываемые после успешного разбора команды.
//!
//! Все относительные пути считаются расположенными на рабочем столе текущего
//! пользователя Windows. Абсолютные пути остаются без изменений. Операции
//! удаления используют файловую систему напрямую и не перемещают элементы
//! в Корзину — перед удалением следует внимательно проверять формулировку.

use std::fs;
use std::path::{Path, PathBuf};
use directories::UserDirs;

/// Набор статических операций над файлами и каталогами; экземпляр не хранит состояние.
pub struct FileManager;

impl FileManager {
    /// Получает путь к рабочему столу именно текущего пользователя Windows.
    pub fn get_desktop_path() -> Result<PathBuf, String> {
        if let Some(user_dirs) = UserDirs::new() {
            if let Some(desktop) = user_dirs.desktop_dir() {
                return Ok(desktop.to_path_buf());
            }
        }
        Err("Не удалось определить путь к рабочему столу.".to_string())
    }

    /// Превращает относительный путь в абсолютный путь на рабочем столе.
    /// Абсолютные пути (например, `D:\Data\file.txt`) не изменяются.
    fn resolve_path(path_str: &str) -> Result<PathBuf, String> {
        let path = Path::new(path_str);
        if path.is_absolute() {
            Ok(path.to_path_buf())
        } else {
            let desktop = Self::get_desktop_path()?;
            Ok(desktop.join(path))
        }
    }

    /// Создаёт каталог вместе со всеми отсутствующими родительскими каталогами.
    /// Повторный вызов для уже существующего каталога не считается ошибкой.
    pub fn create_dir(path_str: &str) -> Result<(), String> {
        let target_path = Self::resolve_path(path_str)?;
        fs::create_dir_all(&target_path)
            .map_err(|e| format!("Ошибка создания папки '{}': {}", target_path.display(), e))?;
        println!("📁 Папка успешно создана: {}", target_path.display());
        Ok(())
    }

    /// Создаёт файл и записывает в него текст. `fs::write` перезаписывает
    /// содержимое существующего файла с таким же путём.
    pub fn create_file(path_str: &str, content: &str) -> Result<(), String> {
        let target_path = Self::resolve_path(path_str)?;
        
        if let Some(parent) = target_path.parent() {
            if !parent.exists() {
                fs::create_dir_all(parent).map_err(|e| format!("Не удалось создать родительскую директорию: {}", e))?;
            }
        }

        fs::write(&target_path, content)
            .map_err(|e| format!("Ошибка создания файла '{}': {}", target_path.display(), e))?;
        println!("📄 Файл успешно создан: {}", target_path.display());
        Ok(())
    }

    /// Переименовывает или перемещает существующий файл/каталог в новый путь.
    /// При необходимости создаёт родительскую папку назначения.
    pub fn rename_or_move(old_path_str: &str, new_path_str: &str) -> Result<(), String> {
        let old_path = Self::resolve_path(old_path_str)?;
        let new_path = Self::resolve_path(new_path_str)?;

        if !old_path.exists() {
            return Err(format!("Исходный объект не найден: {}", old_path.display()));
        }

        if let Some(parent) = new_path.parent() {
            if !parent.exists() {
                fs::create_dir_all(parent).map_err(|e| format!("Не удалось создать целевую директорию: {}", e))?;
            }
        }

        fs::rename(&old_path, &new_path)
            .map_err(|e| format!("Ошибка перемещения/переименования: {}", e))?;
        println!("🔄 Успешно перемещено/переименовано в: {}", new_path.display());
        Ok(())
    }

    /// Удаляет один файл или целый каталог вместе с содержимым.
    /// Это окончательное удаление через файловую систему, не через Корзину.
    pub fn delete_item(path_str: &str) -> Result<(), String> {
        let target_path = Self::resolve_path(path_str)?;

        if !target_path.exists() {
            return Err(format!("Объект для удаления не найден: {}", target_path.display()));
        }

        let was_directory = target_path.is_dir();
        if was_directory {
            fs::remove_dir_all(&target_path)
                .map_err(|e| format!("Ошибка удаления папки '{}': {}", target_path.display(), e))?;
            println!("🗑️ Папка удалена: {}", target_path.display());
            notify_shell_change(&target_path, 0x0000_0010); // SHCNE_RMDIR
        } else {
            fs::remove_file(&target_path)
                .map_err(|e| format!("Ошибка удаления файла '{}': {}", target_path.display(), e))?;
            println!("🗑️ Файл удален: {}", target_path.display());
            notify_shell_change(&target_path, 0x0000_0004); // SHCNE_DELETE
        }

        // Рабочий стол — обычная папка Windows. Сообщаем Проводнику,
        // что содержимое родительской папки изменилось.
        if let Some(parent) = target_path.parent() {
            notify_shell_change(parent, 0x0000_1000); // SHCNE_UPDATEDIR
        }
        Ok(())
    }

    /// Удалить все файлы и папки ВНУТРИ указанной директории, но не саму директорию
    /// Удаляет все непосредственные элементы каталога и их содержимое,
    /// сохраняя сам выбранный каталог.
    pub fn delete_all_in_dir(path_str: &str) -> Result<(), String> {
        let target_path = Self::resolve_path(path_str)?;

        if !target_path.exists() || !target_path.is_dir() {
            return Err(format!("Папка не найдена: {}", target_path.display()));
        }

        let entries = fs::read_dir(&target_path)
            .map_err(|e| format!("Не удалось прочитать содержимое папки: {}", e))?;

        for entry in entries {
            let entry = entry.map_err(|e| format!("Ошибка чтения элемента папки: {}", e))?;
            let path = entry.path();
            if path.is_dir() {
                fs::remove_dir_all(&path).map_err(|e| format!("Ошибка удаления подпапки: {}", e))?;
                notify_shell_change(&path, 0x0000_0010); // SHCNE_RMDIR
            } else {
                fs::remove_file(&path).map_err(|e| format!("Ошибка удаления файла: {}", e))?;
                notify_shell_change(&path, 0x0000_0004); // SHCNE_DELETE
            }
        }

        notify_shell_change(&target_path, 0x0000_1000); // SHCNE_UPDATEDIR
        println!("🧹 Папка '{}' очищена от всех файлов.", target_path.display());
        Ok(())
    }
}

/// Сообщает Проводнику Windows об изменении файловой системы.
/// На остальных операционных системах функция ничего не делает.
/// Обновляет уведомления оболочки Windows, чтобы Проводник сразу увидел изменения.
#[cfg(windows)]
fn notify_shell_change(path: &Path, event: i32) {
    use std::os::windows::ffi::OsStrExt;

    #[link(name = "shell32")]
    extern "system" {
        fn SHChangeNotify(
            event_id: i32,
            flags: u32,
            item1: *const std::ffi::c_void,
            item2: *const std::ffi::c_void,
        );
    }

    const SHCNF_PATHW: u32 = 0x0005;
    const SHCNF_FLUSH: u32 = 0x1000;

    let mut wide_path: Vec<u16> = path.as_os_str().encode_wide().collect();
    wide_path.push(0);

    unsafe {
        SHChangeNotify(
            event,
            SHCNF_PATHW | SHCNF_FLUSH,
            wide_path.as_ptr().cast(),
            std::ptr::null(),
        );
    }
}

#[cfg(not(windows))]
fn notify_shell_change(_path: &Path, _event: i32) {}