//! Безопасное удаление самого приложения.
//!
//! Приложение удаляет только собственный EXE. Полностью удалить папку можно
//! только если она содержит маркер, создаваемый build_windows.bat в dist.
//! Исходники проекта, документы пользователя и системные каталоги не трогаются.

use std::path::{Path, PathBuf};

// Маркер создаёт build_windows.bat только внутри переносимой папки dist.
// Без совпадения имени папки и содержимого маркера каталог целиком не удаляется.
const INSTALL_MARKER_NAME: &str = "LOCAL_AI_ASSISTANT_INSTALL.txt";
const INSTALL_MARKER_VALUE: &str = "LOCAL_AI_ASSISTANT_PORTABLE_INSTALL_V1";

/// Распознаёт несколько явных фраз, которыми пользователь может запросить удаление.
pub fn is_request(input: &str) -> bool {
    let normalized = normalize(input);
    matches!(
        normalized.as_str(),
        "самоуничтожение"
            | "режим самоуничтожения"
            | "удали себя"
            | "удалить себя"
            | "удали ассистента"
            | "удалить ассистента"
            | "удали приложение"
            | "удалить приложение"
            | "деинсталлируй себя"
            | "деинсталлируй ассистента"
    )
}

/// Проверяет точную подтверждающую фразу. Одного запроса на удаление недостаточно.
pub fn is_confirmation(input: &str) -> bool {
    matches!(normalize(input).as_str(), "удалить ассистента" | "подтверждаю удаление")
}

/// Нормализует регистр, «ё» и завершающую пунктуацию для сравнения фраз.
fn normalize(input: &str) -> String {
    input
        .to_lowercase()
        .replace('ё', "е")
        .trim()
        .trim_end_matches(|ch| matches!(ch, '?' | '!' | '.'))
        .trim()
        .to_string()
}

/// Безопасно выбранная цель: отдельный EXE либо помеченная папка dist.
#[derive(Debug, Clone)]
struct RemovalTarget {
    /// Абсолютный путь к выбранному EXE или к папке `dist`.
    path: PathBuf,
    /// `true`, только если папка `dist` прошла проверку маркера.
    is_directory: bool,
    /// Человекочитаемое описание того, что именно будет удалено.
    description: String,
}

/// Разрешает цель удаления только для файла с ожидаемым именем.
/// Папку целиком разрешает удалить лишь если это `dist` с точным маркером сборки.
fn choose_removal_target(executable: &Path) -> Result<RemovalTarget, String> {
    let file_name = executable
        .file_name()
        .and_then(|name| name.to_str())
        .unwrap_or_default();
    if !file_name.eq_ignore_ascii_case("local_ai_assistant.exe") {
        return Err("Удаление остановлено: имя исполняемого файла не совпадает с Local AI Assistant. Ничего не удалено.".to_string());
    }

    let parent = executable
        .parent()
        .ok_or_else(|| "Не удалось определить папку приложения.".to_string())?;
    let marker = parent.join(INSTALL_MARKER_NAME);
    let marked_dist = parent
        .file_name()
        .and_then(|name| name.to_str())
        .map(|name| name.eq_ignore_ascii_case("dist"))
        .unwrap_or(false)
        && std::fs::read_to_string(&marker)
            .map(|value| value.trim() == INSTALL_MARKER_VALUE)
            .unwrap_or(false);

    if marked_dist {
        Ok(RemovalTarget {
            path: parent.to_path_buf(),
            is_directory: true,
            description: format!("портативную папку приложения: {}", parent.display()),
        })
    } else {
        Ok(RemovalTarget {
            path: executable.to_path_buf(),
            is_directory: false,
            description: format!("только исполняемый файл: {}", executable.display()),
        })
    }
}

/// Запускает временную копию EXE, которая дождётся выхода основного процесса
/// и удалит только заранее проверенную цель вместе с настройкой хоткея.
#[cfg(windows)]
pub fn spawn_uninstaller() -> Result<String, String> {
    use std::ffi::OsStr;
    use std::process::{Command, Stdio};
    use std::time::{SystemTime, UNIX_EPOCH};

    const CREATE_NO_WINDOW: u32 = 0x0800_0000;

    let executable = std::env::current_exe()
        .map_err(|error| format!("Не удалось определить расположение приложения: {error}"))?;
    let target = choose_removal_target(&executable)?;

    let project = directories::ProjectDirs::from("com", "LocalAI", "Assistant")
        .ok_or_else(|| "Не удалось определить папку настроек приложения.".to_string())?;
    let settings_file = project.config_dir().join("hotkey.txt");

    let timestamp = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_millis();
    let helper = std::env::temp_dir().join(format!(
        "local-ai-assistant-cleanup-{}-{timestamp}.exe",
        std::process::id()
    ));
    std::fs::copy(&executable, &helper)
        .map_err(|error| format!("Не удалось подготовить безопасный помощник удаления: {error}"))?;

    let mut command = Command::new(&helper);
    command
        .arg("--cleanup")
        .arg(std::process::id().to_string())
        .arg(if target.is_directory { "directory" } else { "file" })
        .arg(&target.path)
        .arg(&settings_file)
        .stdin(Stdio::null())
        .stdout(Stdio::null())
        .stderr(Stdio::null());

    use std::os::windows::process::CommandExt;
    command.creation_flags(CREATE_NO_WINDOW);
    if let Err(error) = command.spawn() {
        let _ = std::fs::remove_file(&helper);
        return Err(format!("Не удалось запустить помощник удаления: {error}"));
    }

    Ok(format!(
        "Удаление подготовлено. Будет удалена {} и файл пользовательской настройки горячей клавиши. Исходники проекта и пользовательские документы не затрагиваются.",
        target.description
    ))
}

#[cfg(not(windows))]
pub fn spawn_uninstaller() -> Result<String, String> {
    Err("Самостоятельное удаление доступно только в Windows-сборке.".to_string())
}

/// Проверяет аргумент `--cleanup`. Если он присутствует, выполняет режим
/// помощника и возвращает `true`, чтобы обычный интерфейс не запускался.
pub fn run_cleanup_mode() -> bool {
    use std::ffi::OsStr;

    let mut args = std::env::args_os();
    let _program = args.next();
    if args.next().as_deref() != Some(OsStr::new("--cleanup")) {
        return false;
    }

    #[cfg(windows)]
    {
        let parent_pid = args.next().and_then(|value| value.to_string_lossy().parse::<u32>().ok());
        let target_kind = args.next().unwrap_or_default().to_string_lossy().to_string();
        let target_path = args.next().map(PathBuf::from);
        let settings_path = args.next().map(PathBuf::from);
        if let (Some(pid), Some(target), Some(settings)) = (parent_pid, target_path, settings_path) {
            cleanup_after_parent_exit(pid, &target_kind, &target, &settings);
        }
    }
    #[cfg(not(windows))]
    {
        let _ = args.next();
        let _ = args.next();
        let _ = args.next();
        let _ = args.next();
    }
    true
}

/// Дожидается закрытия GUI, повторяет удаление заблокированного EXE и удаляет
/// файл настройки. Временная копия помощника помечается для удаления при перезапуске.
#[cfg(windows)]
fn cleanup_after_parent_exit(parent_pid: u32, target_kind: &str, target: &Path, settings_file: &Path) {
    use std::thread;
    use std::time::Duration;

    // Дожидаемся завершения GUI-процесса, который запустил помощник.
    unsafe {
        let process = OpenProcess(0x0010_0000, 0, parent_pid);
        if process != 0 {
            let _ = WaitForSingleObject(process, u32::MAX);
            CloseHandle(process);
        } else {
            // Родитель мог успеть завершиться до запуска помощника.
            thread::sleep(Duration::from_secs(2));
        }
    }

    if target_kind == "directory" {
        // Защита от изменения аргументов: каталог удаляется только если он всё
        // ещё называется dist и содержит наш специальный маркер сборки.
        let marker = target.join(INSTALL_MARKER_NAME);
        let safe_dist = target
            .file_name()
            .and_then(|name| name.to_str())
            .map(|name| name.eq_ignore_ascii_case("dist"))
            .unwrap_or(false)
            && std::fs::read_to_string(&marker)
                .map(|value| value.trim() == INSTALL_MARKER_VALUE)
                .unwrap_or(false);
        if safe_dist {
            retry_delete_directory(target);
        }
    } else if target_kind == "file" {
        retry_delete_file(target);
    }

    retry_delete_file(settings_file);

    // Запланировать удаление временной копии помощника при следующей загрузке
    // Windows: запущенный EXE нельзя удалить немедленно на Windows.
    if let Ok(helper_exe) = std::env::current_exe() {
        let wide: Vec<u16> = helper_exe.as_os_str().encode_wide().chain(Some(0)).collect();
        unsafe {
            let _ = MoveFileExW(wide.as_ptr(), std::ptr::null(), 0x0000_0004);
        }
    }
}

/// Повторяет удаление каталога, пока Windows освобождает занятые файлы.
#[cfg(windows)]
fn retry_delete_directory(path: &Path) {
    use std::thread;
    use std::time::Duration;
    for _ in 0..40 {
        if !path.exists() || std::fs::remove_dir_all(path).is_ok() {
            return;
        }
        thread::sleep(Duration::from_millis(250));
    }
}

/// Повторяет удаление файла, если он ещё временно заблокирован процессом.
#[cfg(windows)]
fn retry_delete_file(path: &Path) {
    use std::thread;
    use std::time::Duration;
    for _ in 0..40 {
        if !path.exists() || std::fs::remove_file(path).is_ok() {
            return;
        }
        thread::sleep(Duration::from_millis(250));
    }
}

#[cfg(windows)]
use std::os::windows::ffi::OsStrExt;

#[cfg(windows)]
#[link(name = "kernel32")]
extern "system" {
    fn OpenProcess(desired_access: u32, inherit_handle: i32, process_id: u32) -> isize;
    fn WaitForSingleObject(handle: isize, milliseconds: u32) -> u32;
    fn CloseHandle(handle: isize) -> i32;
    fn MoveFileExW(existing_file_name: *const u16, new_file_name: *const u16, flags: u32) -> i32;
}

#[cfg(test)]
mod tests {
    use super::{is_request, normalize};

    #[test]
    fn recognizes_explicit_uninstall_requests() {
        assert!(is_request("самоуничтожение"));
        assert!(is_request("Удали ассистента!"));
        assert!(is_request("удали себя"));
    }

    #[test]
    fn normalizes_confirmation_phrase() {
        assert_eq!(normalize("УДАЛИТЬ АССИСТЕНТА."), "удалить ассистента");
        assert!(super::is_confirmation("УДАЛИТЬ АССИСТЕНТА"));
        assert!(super::is_confirmation("Подтверждаю удаление"));
    }
}
